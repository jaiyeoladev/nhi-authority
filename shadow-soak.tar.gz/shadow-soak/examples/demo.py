"""End-to-end demo of a shadow-deny soak lifecycle.

Imports the three shadow-deny actions from a real ``agent-authority`` plan,
starts their soaks, then simulates two weeks of shadow-deny telemetry in which:

* ``kms:Decrypt`` is quietly exercised by a dependent batch job on day 6 — a
  blocked-but-logged event that must *save* the permission from revocation;
* ``kms:ScheduleKeyDeletion`` and ``sts:AssumeRole`` are never touched — their
  soaks should come back CLEAR and be safe to revoke.

Run from the repo root::

    python examples/demo.py
"""

from __future__ import annotations

import sys
import tempfile
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from shadow_soak import (  # noqa: E402
    Store, ShadowEvent, SoakState, import_plan_file, start_soak, tick, resolve,
)

PLAN = Path(__file__).parent / "plan.json"


def banner(t): print("\n" + "=" * 72 + f"\n{t}\n" + "=" * 72)


def main() -> None:
    # Fresh throwaway DB so the demo is repeatable.
    db = tempfile.mktemp(suffix=".db")
    store = Store(db)

    # We pin "now" to a fixed start and advance it manually so a 14-day soak can
    # play out in a few lines instead of a fortnight.
    t0 = time.time()
    day = 86400

    banner("IMPORT shadow-deny actions from the agent-authority plan")
    soaks = import_plan_file(store, str(PLAN), soak_days=14, auto_start=False, now=t0)
    for s in soaks:
        print(f"  imported {s.id}  {s.footprint()}  [{s.state.value}]")

    banner("START all soaks (day 0)")
    for s in soaks:
        started = start_soak(store, s.id, now=t0)
        print(f"  {started.id}  → {started.state.value}")

    # Day 6: a dependent system tries to use kms:Decrypt — shadow-deny logs it.
    decrypt = next(s for s in soaks if s.action == "kms:Decrypt")
    store.ingest_events([
        ShadowEvent(
            identity_id=decrypt.identity_id,
            action="kms:Decrypt",
            resource="arn:aws:kms:eu-west-2:111:key/abc-123",
            timestamp=t0 + 6 * day,
            event_id="evt-decrypt-day6",
        )
    ])
    print("\n(day 6: batch job attempted kms:Decrypt — blocked-but-logged)")

    banner("TICK at day 7 (mid-soak)")
    for d in tick(store, now=t0 + 7 * day):
        print(f"  [{d.state.value:>16}] {d.soak_id}  {d.rationale}")

    banner("TICK at day 15 (after the 14-day window closes)")
    for d in tick(store, now=t0 + 15 * day):
        print(f"  [{d.state.value:>16}] {d.soak_id}  {d.rationale}")

    banner("RESULTING STATE")
    for s in store.list_soaks():
        print(f"  [{s.state.value:>16}] {s.footprint()}  (detach: {', '.join(s.sources) or '—'})")

    banner("OPERATOR CLOSES THE LOOP")
    for s in store.list_soaks():
        if s.state is SoakState.CLEAR:
            resolve(store, s.id, SoakState.REVOKED,
                    "Clean soak confirmed; revocation applied via change CR-1042.",
                    now=t0 + 15 * day)
            print(f"  REVOKED  {s.footprint()}")
        elif s.state is SoakState.DEPENDENCY_FOUND:
            resolve(store, s.id, SoakState.RESTORED,
                    "Dependency (batch decrypt) confirmed; permission kept.",
                    now=t0 + 15 * day)
            print(f"  RESTORED {s.footprint()}  ← saved from a bad revocation")

    banner("AUDIT TRAIL for the kms:Decrypt soak")
    for t in store.transitions(decrypt.id):
        ts = time.strftime("%Y-%m-%d", time.localtime(t["at"]))
        print(f"  {ts}  {t['from_state']} → {t['to_state']}: {t['rationale']}")

    store.close()
    Path(db).unlink(missing_ok=True)


if __name__ == "__main__":
    main()
