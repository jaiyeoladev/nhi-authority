# Soak state machine

A soak is the controlled trial a permission goes through before it is actually
revoked. States and the transitions the engine allows:

```
                 start                 tick (window open, no evidence)
   PENDING ───────────────▶ SOAKING ──────────────────────────▶ SOAKING
      │                        │  │  │
      │ abort                  │  │  └── blocked event matches ──▶ DEPENDENCY_FOUND
      ▼                        │  │                                     │
   ABORTED                     │  └── window closed, covered,          │ restore
                               │      no matches ───────▶ CLEAR         ▼
                               │                           │        RESTORED
                               └── window closed,          │
                                   coverage < floor        │ operator applies
                                   ───────▶ INCONCLUSIVE   │ revocation
                                             │             ▼
                                   extend ──▶ SOAKING   REVOKED
```

## The states

| State | Meaning | Operator action |
|---|---|---|
| **PENDING** | Created from a plan or by hand; trial not started. | start it |
| **SOAKING** | Shadow-deny active; window still open. | wait; keep feeding telemetry |
| **DEPENDENCY_FOUND** | A blocked-but-logged event fell under the permission's footprint. Something real depends on it. | keep the permission; mark RESTORED |
| **CLEAR** | Window closed, telemetry covered it, zero matching events. Safe to revoke. | revoke; mark REVOKED |
| **INCONCLUSIVE** | Window closed but telemetry coverage was below the floor. We weren't watching enough to trust the silence. | extend the soak or fix log coverage |
| **REVOKED** | Operator applied the revocation. Loop closed. | — (terminal) |
| **RESTORED** | Dependency found; permission kept. | — (terminal) |
| **ABORTED** | Operator cancelled. | — (terminal) |

## Two invariants the engine enforces

1. **No shortcut to REVOKED.** A soak can only reach REVOKED from CLEAR, and
   CLEAR requires a *closed, covered* window with no matching events. The
   transition table in `model.py` is the single source of truth; the engine
   never writes a state that `can_transition` rejects.

2. **A dependency can always veto, even late.** CLEAR and INCONCLUSIVE can still
   fall to DEPENDENCY_FOUND if a matching blocked event arrives after the
   window closes. Evidence that something depends on a permission always wins
   over a prior "looks clear".

## Why INCONCLUSIVE exists

The dangerous failure mode is a soak that sees no blocked events *because the
telemetry pipeline was down*, and is therefore read as safe. `log_coverage`
(fraction of the window actually observed) gates the CLEAR verdict against
`min_coverage`. Below the floor the soak is INCONCLUSIVE — never CLEAR — so a
monitoring gap can never be laundered into a revocation.
