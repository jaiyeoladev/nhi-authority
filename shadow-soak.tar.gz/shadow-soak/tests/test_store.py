import tempfile

from shadow_soak import Store, Soak, SoakState, ShadowEvent


def _store():
    return Store(tempfile.mktemp(suffix=".db"))


def _soak(**kw):
    base = dict(id="s1", identity_id="id1", action="s3:*", resource="b/*",
                sources=["policy:a"], state=SoakState.PENDING)
    base.update(kw)
    return Soak(**base)


def test_roundtrip_soak():
    store = _store()
    store.upsert_soak(_soak(note="hello"))
    got = store.get_soak("s1")
    assert got.action == "s3:*"
    assert got.sources == ["policy:a"]
    assert got.note == "hello"


def test_upsert_does_not_reset_existing():
    store = _store()
    store.upsert_soak(_soak(state=SoakState.PENDING))
    s = store.get_soak("s1")
    s.state = SoakState.SOAKING
    s.started_at = 123.0
    store.save_soak(s)
    # re-importing the same id must not clobber the in-flight state
    store.upsert_soak(_soak(state=SoakState.PENDING))
    assert store.get_soak("s1").state is SoakState.SOAKING
    assert store.get_soak("s1").started_at == 123.0


def test_event_ingestion_is_idempotent():
    store = _store()
    evs = [ShadowEvent("id1", "s3:GetObject", "b/x", 100.0, "evt-1")]
    assert store.ingest_events(evs) == 1
    assert store.ingest_events(evs) == 0           # same event_id → ignored
    assert len(store.events_for_identity("id1")) == 1


def test_list_by_state():
    store = _store()
    store.upsert_soak(_soak(id="a", state=SoakState.SOAKING))
    store.upsert_soak(_soak(id="b", state=SoakState.CLEAR))
    assert {s.id for s in store.list_soaks(SoakState.SOAKING)} == {"a"}
    assert len(store.list_soaks()) == 2


def test_transition_log():
    store = _store()
    store.upsert_soak(_soak())
    store.record_transition("s1", SoakState.PENDING, SoakState.SOAKING, "started", 1.0)
    store.record_transition("s1", SoakState.SOAKING, SoakState.CLEAR, "done", 2.0)
    hist = store.transitions("s1")
    assert [h["to_state"] for h in hist] == ["soaking", "clear"]


def test_persistence_across_reopen():
    path = tempfile.mktemp(suffix=".db")
    s1 = Store(path)
    s1.upsert_soak(_soak(id="keep"))
    s1.close()
    s2 = Store(path)
    assert s2.get_soak("keep") is not None
