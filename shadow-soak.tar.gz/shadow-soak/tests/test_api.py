import json
import tempfile
import threading
import urllib.error
import urllib.request

from shadow_soak import Store, Soak, SoakState
from shadow_soak.api import make_server, soak_to_dict


def _req(url, method="GET", body=None):
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(url, data=data, method=method,
                                 headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req) as r:
        return r.status, json.loads(r.read())


def _running_server():
    store = Store(tempfile.mktemp(suffix=".db"))
    store.upsert_soak(Soak(
        id="s1", identity_id="id1", action="kms:Decrypt",
        resource="arn:aws:kms:*:*:key/*", sources=["policy:k"],
        state=SoakState.SOAKING, started_at=1000.0, soak_seconds=14 * 86400,
    ))
    server = make_server(store, "127.0.0.1", 0)  # port 0 → OS picks a free port
    port = server.server_address[1]
    t = threading.Thread(target=server.serve_forever, daemon=True)
    t.start()
    return server, store, port


def test_soak_to_dict_has_remaining():
    s = Soak(id="x", identity_id="i", action="a", resource="r",
             state=SoakState.SOAKING, started_at=1000.0, soak_seconds=10 * 86400)
    d = soak_to_dict(s, now=1000.0 + 86400)
    assert d["seconds_remaining"] > 0
    assert d["footprint"] == "a r"


def test_api_list_and_detail():
    server, store, port = _running_server()
    try:
        base = f"http://127.0.0.1:{port}"
        status, body = _req(base + "/api/soaks")
        assert status == 200 and len(body["soaks"]) == 1
        status, body = _req(base + "/api/soaks/s1")
        assert status == 200 and body["soak"]["id"] == "s1"
    finally:
        server.shutdown()


def test_api_ingest_and_tick_flow():
    server, store, port = _running_server()
    try:
        base = f"http://127.0.0.1:{port}"
        # ingest a matching blocked event
        status, body = _req(base + "/api/events", "POST", [
            {"identity_id": "id1", "action": "kms:Decrypt",
             "resource": "arn:aws:kms:eu:1:key/x", "timestamp": 1000.0 + 86400,
             "event_id": "e1"},
        ])
        assert status == 200 and body["ingested"] == 1
        status, body = _req(base + "/api/tick", "POST")
        assert status == 200
        states = {d["soak_id"]: d["state"] for d in body["decisions"]}
        assert states["s1"] == "dependency_found"
    finally:
        server.shutdown()


def test_api_resolve_rejects_bad_target():
    server, store, port = _running_server()
    try:
        base = f"http://127.0.0.1:{port}"
        try:
            _req(base + "/api/resolve", "POST", {"soak_id": "s1", "to": "soaking"})
            assert False, "should have raised HTTPError 400"
        except urllib.error.HTTPError as e:
            assert e.code == 400
    finally:
        server.shutdown()


def test_dashboard_served():
    server, store, port = _running_server()
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/") as r:
            html = r.read().decode()
        assert "shadow-soak" in html
    finally:
        server.shutdown()
