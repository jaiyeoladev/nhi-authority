import json
import tempfile

from shadow_soak import Store, SoakState, soaks_from_plan, import_plan_file, soak_id_for

PLAN = {
    "identity": "AGENT-1",
    "actions": [
        {"action": "s3:PutObject", "resource": "b/*", "stage": "monitor",
         "sources": ["policy:x"]},
        {"action": "kms:Decrypt", "resource": "arn:aws:kms:*:*:key/*",
         "stage": "shadow_deny", "sources": ["policy:key-admin"], "reason": "unused"},
        {"action": "sts:AssumeRole", "resource": "arn:*:role/r",
         "stage": "shadow_deny", "sources": ["policy:assume"]},
    ],
}


def test_only_shadow_deny_actions_become_soaks():
    soaks = soaks_from_plan(PLAN)
    assert len(soaks) == 2
    assert {s.action for s in soaks} == {"kms:Decrypt", "sts:AssumeRole"}


def test_soak_id_is_stable_and_idempotent():
    a = soak_id_for("AGENT-1", "kms:Decrypt", "arn:aws:kms:*:*:key/*")
    b = soak_id_for("AGENT-1", "kms:Decrypt", "arn:aws:kms:*:*:key/*")
    assert a == b


def test_import_file_upserts_pending(tmp_path=None):
    store = Store(tempfile.mktemp(suffix=".db"))
    p = tempfile.mktemp(suffix=".json")
    with open(p, "w") as fh:
        json.dump(PLAN, fh)
    soaks = import_plan_file(store, p)
    assert all(s.state is SoakState.PENDING for s in soaks)
    # re-import must not duplicate
    again = import_plan_file(store, p)
    assert len(store.list_soaks()) == 2
    assert len(again) == 2


def test_import_with_autostart():
    store = Store(tempfile.mktemp(suffix=".db"))
    p = tempfile.mktemp(suffix=".json")
    with open(p, "w") as fh:
        json.dump(PLAN, fh)
    soaks = import_plan_file(store, p, auto_start=True, now=1000.0)
    assert all(s.state is SoakState.SOAKING for s in soaks)
    assert all(s.started_at == 1000.0 for s in soaks)
    assert all(s.sources for s in soaks)
