import tempfile

from shadow_soak import (
    Store, Soak, SoakState, ShadowEvent, evaluate, matching_events, tick,
    start_soak, resolve, set_coverage, can_transition,
)

DAY = 86400


def _soak(**kw):
    base = dict(id="s1", identity_id="id1", action="kms:Decrypt",
                resource="arn:aws:kms:*:*:key/*", soak_seconds=14 * DAY,
                started_at=1000.0, state=SoakState.SOAKING)
    base.update(kw)
    return Soak(**base)


def test_matching_events_filters_by_footprint_and_time():
    soak = _soak(started_at=1000.0)
    evs = [
        ShadowEvent("id1", "kms:Decrypt", "arn:aws:kms:eu:1:key/x", 2000.0, "e1"),  # match
        ShadowEvent("id1", "s3:GetObject", "b/x", 2000.0, "e2"),                    # wrong action
        ShadowEvent("id2", "kms:Decrypt", "arn:aws:kms:eu:1:key/x", 2000.0, "e3"),  # wrong identity
        ShadowEvent("id1", "kms:Decrypt", "arn:aws:kms:eu:1:key/x", 500.0, "e4"),   # before start
    ]
    m = matching_events(soak, evs)
    assert [e.event_id for e in m] == ["e1"]


def test_dependency_event_wins():
    soak = _soak()
    evs = [ShadowEvent("id1", "kms:Decrypt", "arn:aws:kms:eu:1:key/x", 1000 + DAY, "e1")]
    d = evaluate(soak, evs, now=1000 + 2 * DAY)
    assert d.state is SoakState.DEPENDENCY_FOUND
    assert d.dependency_events


def test_window_open_is_soaking():
    soak = _soak(started_at=1000.0, soak_seconds=14 * DAY)
    d = evaluate(soak, [], now=1000 + 7 * DAY)
    assert d.state is SoakState.SOAKING
    assert d.seconds_remaining > 0


def test_closed_and_covered_is_clear():
    soak = _soak(log_coverage=1.0, min_coverage=0.9)
    d = evaluate(soak, [], now=1000 + 15 * DAY)
    assert d.state is SoakState.CLEAR


def test_closed_low_coverage_is_inconclusive():
    soak = _soak(log_coverage=0.5, min_coverage=0.9)
    d = evaluate(soak, [], now=1000 + 15 * DAY)
    assert d.state is SoakState.INCONCLUSIVE


def test_dependency_overrides_even_after_clear_window():
    # Window closed & covered, but a matching event exists → dependency wins.
    soak = _soak(log_coverage=1.0)
    evs = [ShadowEvent("id1", "kms:Decrypt", "arn:aws:kms:eu:1:key/x", 1000 + DAY, "e1")]
    d = evaluate(soak, evs, now=1000 + 15 * DAY)
    assert d.state is SoakState.DEPENDENCY_FOUND


def test_no_shortcut_to_revoked():
    # The state machine forbids SOAKING → REVOKED directly.
    assert not can_transition(SoakState.SOAKING, SoakState.REVOKED)
    assert can_transition(SoakState.CLEAR, SoakState.REVOKED)


def test_tick_persists_clear_and_dependency():
    store = Store(tempfile.mktemp(suffix=".db"))
    t0 = 1000.0
    clean = _soak(id="clean", action="sts:AssumeRole", resource="arn:*:role/x",
                  started_at=t0, state=SoakState.SOAKING, log_coverage=1.0)
    dep = _soak(id="dep", action="kms:Decrypt", resource="arn:aws:kms:*:*:key/*",
                started_at=t0, state=SoakState.SOAKING, log_coverage=1.0)
    store.upsert_soak(clean)
    store.upsert_soak(dep)
    store.ingest_events([
        ShadowEvent("id1", "kms:Decrypt", "arn:aws:kms:eu:1:key/x", t0 + DAY, "e1")
    ])
    tick(store, now=t0 + 15 * DAY)
    assert store.get_soak("clean").state is SoakState.CLEAR
    assert store.get_soak("dep").state is SoakState.DEPENDENCY_FOUND


def test_start_and_resolve_flow():
    store = Store(tempfile.mktemp(suffix=".db"))
    store.upsert_soak(_soak(id="s", state=SoakState.PENDING, started_at=None))
    s = start_soak(store, "s", now=1000.0)
    assert s.state is SoakState.SOAKING and s.started_at == 1000.0
    # can't jump a soaking soak straight to revoked
    blocked = resolve(store, "s", SoakState.REVOKED, "nope")
    assert blocked.state is SoakState.SOAKING
    # abort is always legal
    aborted = resolve(store, "s", SoakState.ABORTED, "cancelled")
    assert aborted.state is SoakState.ABORTED


def test_set_coverage_clamps():
    store = Store(tempfile.mktemp(suffix=".db"))
    store.upsert_soak(_soak(id="s"))
    assert set_coverage(store, "s", 1.5).log_coverage == 1.0
    assert set_coverage(store, "s", -0.2).log_coverage == 0.0
