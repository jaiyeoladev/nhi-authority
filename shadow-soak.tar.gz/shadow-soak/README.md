# shadow-soak

**Operational tracker for shadow-deny soaks.** Runs the controlled trials that a
least-privilege planner proposes: watch a permission under shadow-deny, surface
real dependencies as *blocked-but-logged* events, and promote each permission to
revoke-safe or hold it back — with a full audit trail.

This is the operational companion to
[`agent-authority`](../agent-authority): that tool decides a permission *looks*
unused but can't be sure nothing depends on it, so it proposes a **shadow-deny**
(deny in audit-only mode, keep serving the call, watch for a would-have-been-
blocked event). `shadow-soak` runs those soaks and closes the loop.

> **Why it matters:** the dependency you can't see in the logs is the one that
> causes the outage. Shadow-soak turns "I think nothing uses this" into a
> reversible experiment, so a permission is only ever revoked after a clean,
> *observed* soak — and is saved the moment a real dependency shows up.

## What it does

- **Imports shadow-deny actions** straight from an `agent-authority` plan
  (`analyze --json`), idempotently — re-importing never resets a soak in flight.
- **Ingests blocked-but-logged telemetry** idempotently (events carry a provider
  `event_id`; replaying a log page never double-counts).
- **Evaluates each soak** against time *and* telemetry coverage, and moves it
  along a strict state machine — never a shortcut to "revoked".
- **Serves a zero-dependency web dashboard + JSON API** and a CLI.
- **Keeps an append-only audit trail** of every state change and its reason —
  exactly what a change review asks for.

## The one safety rule

**Absence of evidence is only evidence of absence when you were actually
watching.** A soak that sees no blocked events is `CLEAR` *only if* telemetry
covered the window (`log_coverage ≥ min_coverage`). A gap in the shadow-deny log
stream makes the soak `INCONCLUSIVE`, never `CLEAR`, so a monitoring outage can
never be laundered into a revocation. And a matching blocked event always wins —
even after a window has closed clear, late evidence of a dependency vetoes the
revocation.

Full state machine: **[docs/STATES.md](docs/STATES.md)**.

## Install

```bash
pip install -e .          # editable install
pip install -e ".[dev]"   # with pytest
```

Zero runtime dependencies — pure standard library (`sqlite3`, `http.server`).

## Quick start

```bash
# 1. Import the shadow-deny actions from an agent-authority plan and start them
shadow-soak import-plan examples/plan.json --start

# 2. Feed in blocked-but-logged telemetry (repeat as it arrives)
shadow-soak ingest events.json

# 3. Evaluate — run on a cron / timer
shadow-soak tick
shadow-soak status

# 4. Or run the dashboard + API
shadow-soak serve           # http://127.0.0.1:8787
```

See the whole lifecycle play out — including a permission *saved* from a bad
revocation — in one script:

```bash
python examples/demo.py
```

### As a library

```python
from shadow_soak import Store, import_plan_file, start_soak, tick, resolve, SoakState

store = Store("soak.db")
soaks = import_plan_file(store, "plan.json", soak_days=14, auto_start=True)
# ... telemetry streams in via store.ingest_events(...) ...
for decision in tick(store):
    print(decision.state, decision.rationale)
```

## HTTP API

| Method | Path | Purpose |
|---|---|---|
| GET | `/` | web dashboard |
| GET | `/api/soaks` | all soaks (`?state=soaking` to filter) |
| GET | `/api/soaks/<id>` | one soak + its transition history |
| POST | `/api/tick` | run an evaluation cycle |
| POST | `/api/events` | ingest shadow events (JSON list) |
| POST | `/api/start` | `{"soak_id": ...}` start a pending soak |
| POST | `/api/resolve` | `{"soak_id","to":"revoked\|restored\|aborted","rationale"}` |

> No auth layer is built in by design — run it behind your platform's
> identity-aware proxy, as you would any internal control-plane tool.

## How it fits the pipeline

```
agent-authority  ──analyze --json──▶  plan.json
                                         │ import-plan
                                         ▼
shadow-soak:  PENDING ─start─▶ SOAKING ─┬─ blocked event matches ─▶ DEPENDENCY_FOUND ─▶ RESTORED
                                        │                                               (keep it)
                                        ├─ window closed, covered, clean ─▶ CLEAR ─▶ REVOKED
                                        │                                           (loop closed)
                                        └─ window closed, coverage low ─▶ INCONCLUSIVE ─▶ (extend)
```

## Project layout

```
src/shadow_soak/
  model.py        soaks, events, the state machine + legal transitions
  store.py        thread-safe SQLite persistence (idempotent event ingest, audit log)
  engine.py       pure evaluation + stateful tick (coverage-aware decisions)
  importer.py     ingest agent-authority plan JSON → soaks (idempotent)
  api.py          stdlib HTTP API + served dashboard
  web/dashboard.html   single-file UI, light/dark
  cli.py          shadow-soak import-plan|ingest|start|tick|status|resolve|serve
docs/STATES.md    the state machine, in full
examples/         demo + a real plan.json and events.json
tests/            pytest suite (25 tests: engine, store, importer, live API)
```

## Tests

```bash
pytest -q
```

## License

Apache-2.0 — see [LICENSE](LICENSE).
