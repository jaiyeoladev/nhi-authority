"""Evaluation engine: turn telemetry + time into soak decisions.

The engine is pure where it can be: :func:`evaluate` takes a soak, its matching
events, and ``now``, and returns a :class:`Decision` without touching the
store. :func:`tick` is the stateful wrapper that loads soaks, evaluates each,
and persists any state change along a *legal* transition, recording why.

Decision rules, in priority order:

1. **A matching blocked event ⇒ DEPENDENCY_FOUND.** Any event, at any time,
   whose footprint the soaked permission covers is a live dependency. This wins
   over everything — even a window that already closed clear.
2. **Window still open ⇒ SOAKING.** Report time remaining.
3. **Window closed, coverage ≥ floor, no matches ⇒ CLEAR.** Safe to revoke.
4. **Window closed, coverage < floor ⇒ INCONCLUSIVE.** We weren't watching
   enough to trust the silence.
"""

from __future__ import annotations

import time

from .model import Decision, ShadowEvent, Soak, SoakState, can_transition
from .store import Store


def matching_events(soak: Soak, events: list[ShadowEvent]) -> list[ShadowEvent]:
    """Events that fall under the soaked permission's footprint.

    Only events at or after the soak start count: a blocked attempt from before
    the trial began is not evidence about *this* trial. Events are matched by
    identity and by the permission's action/resource globs.
    """
    start = soak.started_at if soak.started_at is not None else 0.0
    out = []
    for ev in events:
        if ev.identity_id != soak.identity_id:
            continue
        if ev.timestamp < start:
            continue
        if soak.covers(ev.action, ev.resource):
            out.append(ev)
    return out


def evaluate(soak: Soak, events: list[ShadowEvent], now: float | None = None) -> Decision:
    """Pure evaluation of a single soak. Does not mutate or persist."""
    now = now if now is not None else time.time()

    # Rule 1: a live dependency always wins.
    deps = matching_events(soak, events)
    if deps:
        deps_sorted = sorted(deps, key=lambda e: e.timestamp)
        return Decision(
            soak_id=soak.id,
            state=SoakState.DEPENDENCY_FOUND,
            rationale=(
                f"{len(deps)} blocked-but-logged event(s) matched the footprint "
                f"({soak.footprint()}); a dependent system relies on this — keep it."
            ),
            dependency_events=deps_sorted,
        )

    # Not started yet.
    if soak.started_at is None or soak.ends_at is None:
        return Decision(
            soak_id=soak.id,
            state=SoakState.PENDING,
            rationale="Soak not started.",
        )

    # Rule 2: window still open.
    if now < soak.ends_at:
        remaining = soak.ends_at - now
        return Decision(
            soak_id=soak.id,
            state=SoakState.SOAKING,
            rationale=(
                f"Window open; {remaining / 86400:.1f}d remaining; "
                f"no dependency seen yet (coverage {soak.log_coverage:.0%})."
            ),
            seconds_remaining=remaining,
        )

    # Window closed. Rules 3 & 4 hinge on coverage.
    if soak.log_coverage >= soak.min_coverage:
        return Decision(
            soak_id=soak.id,
            state=SoakState.CLEAR,
            rationale=(
                f"Window closed with {soak.log_coverage:.0%} telemetry coverage "
                f"(≥ {soak.min_coverage:.0%} floor) and no matching events — safe to revoke."
            ),
        )
    return Decision(
        soak_id=soak.id,
        state=SoakState.INCONCLUSIVE,
        rationale=(
            f"Window closed but telemetry coverage {soak.log_coverage:.0%} is below the "
            f"{soak.min_coverage:.0%} floor — silence can't be trusted. Extend or fix logging."
        ),
    )


def start_soak(store: Store, soak_id: str, now: float | None = None) -> Soak | None:
    """Move a PENDING soak into SOAKING, stamping the start time."""
    now = now if now is not None else time.time()
    soak = store.get_soak(soak_id)
    if soak is None:
        return None
    if not can_transition(soak.state, SoakState.SOAKING):
        return soak
    frm = soak.state
    soak.state = SoakState.SOAKING
    if soak.started_at is None:
        soak.started_at = now
    store.save_soak(soak)
    store.record_transition(soak_id, frm, SoakState.SOAKING, "Soak started.", now)
    return soak


def apply_decision(store: Store, soak: Soak, decision: Decision, now: float | None = None) -> bool:
    """Persist a decision if it is a legal, non-noop transition. Returns changed."""
    now = now if now is not None else time.time()
    target = decision.state
    if target == soak.state:
        # Refresh rationale-bearing fields that can change without a state move
        # (e.g. remaining time) but don't log a transition for a no-op.
        return False
    if not can_transition(soak.state, target):
        return False
    frm = soak.state
    soak.state = target
    store.save_soak(soak)
    store.record_transition(soak.id, frm, target, decision.rationale, now)
    return True


def tick(store: Store, now: float | None = None) -> list[Decision]:
    """Evaluate every non-terminal soak and persist legal state changes.

    Returns the decision for each soak evaluated, so a caller (CLI, API, cron)
    can surface what moved this cycle.
    """
    now = now if now is not None else time.time()
    decisions: list[Decision] = []
    for soak in store.list_soaks():
        if soak.state.is_terminal:
            continue
        # PENDING soaks aren't auto-started; they wait for an explicit start.
        if soak.state is SoakState.PENDING:
            continue
        events = store.events_for_identity(soak.identity_id)
        decision = evaluate(soak, events, now)
        apply_decision(store, soak, decision, now)
        decisions.append(decision)
    return decisions


def set_coverage(store: Store, soak_id: str, coverage: float) -> Soak | None:
    """Update the telemetry-coverage figure for a soak (from the log pipeline)."""
    soak = store.get_soak(soak_id)
    if soak is None:
        return None
    soak.log_coverage = max(0.0, min(1.0, coverage))
    store.save_soak(soak)
    return soak


def resolve(store: Store, soak_id: str, to: SoakState, rationale: str,
            now: float | None = None) -> Soak | None:
    """Operator-driven terminal move: REVOKED, RESTORED, or ABORTED."""
    now = now if now is not None else time.time()
    soak = store.get_soak(soak_id)
    if soak is None:
        return None
    if not can_transition(soak.state, to):
        return soak
    frm = soak.state
    soak.state = to
    store.save_soak(soak)
    store.record_transition(soak_id, frm, to, rationale, now)
    return soak
