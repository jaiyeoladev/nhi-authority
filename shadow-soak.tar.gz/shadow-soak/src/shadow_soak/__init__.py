"""shadow-soak: operational tracker for shadow-deny soaks.

Runs the controlled trials that ``agent-authority`` proposes: watch a permission
under shadow-deny, surface real dependencies as blocked-but-logged events, and
promote each soak to revoke-safe or hold it back — with a full audit trail.
"""

from .model import (
    Decision,
    ShadowEvent,
    Soak,
    SoakState,
    can_transition,
    soak_id_for,
)
from .store import Store
from .engine import (
    apply_decision,
    evaluate,
    matching_events,
    resolve,
    set_coverage,
    start_soak,
    tick,
)
from .importer import import_plan_file, soaks_from_plan

__version__ = "0.1.0"

__all__ = [
    "Decision", "ShadowEvent", "Soak", "SoakState", "can_transition", "soak_id_for",
    "Store",
    "apply_decision", "evaluate", "matching_events", "resolve", "set_coverage",
    "start_soak", "tick",
    "import_plan_file", "soaks_from_plan",
]
