"""SQLite persistence for soaks and shadow events.

Kept deliberately small and dependency-free (stdlib ``sqlite3``). The store is
the thing that makes this an app rather than a function: soaks live across
restarts, telemetry accumulates over a two-week window, and the engine reads
state back on every tick.

Design choices worth noting:

* **Event ingestion is idempotent.** Events carry a provider ``event_id`` and
  are inserted with ``INSERT OR IGNORE`` keyed on it, so replaying a log page —
  which happens constantly with at-least-once delivery — never double-counts a
  dependency.
* **A transition log is append-only.** Every state change is recorded with its
  rationale and timestamp, giving an audit trail for why a permission was
  revoked or kept — exactly what a change-review will ask for.
"""

from __future__ import annotations

import sqlite3
import time
import threading
from contextlib import contextmanager
from typing import Iterable, Iterator

from .model import ShadowEvent, Soak, SoakState

_SCHEMA = """
CREATE TABLE IF NOT EXISTS soaks (
    id            TEXT PRIMARY KEY,
    identity_id   TEXT NOT NULL,
    action        TEXT NOT NULL,
    resource      TEXT NOT NULL,
    condition     TEXT,
    sources       TEXT NOT NULL,          -- comma-separated grant sources
    state         TEXT NOT NULL,
    started_at    REAL,
    soak_seconds  REAL NOT NULL,
    log_coverage  REAL NOT NULL,
    min_coverage  REAL NOT NULL,
    origin        TEXT NOT NULL,
    note          TEXT NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS events (
    event_id     TEXT PRIMARY KEY,         -- dedupe key
    identity_id  TEXT NOT NULL,
    action       TEXT NOT NULL,
    resource     TEXT NOT NULL,
    timestamp    REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_events_identity ON events(identity_id);

CREATE TABLE IF NOT EXISTS transitions (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    soak_id      TEXT NOT NULL,
    from_state   TEXT NOT NULL,
    to_state     TEXT NOT NULL,
    rationale    TEXT NOT NULL,
    at           REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_transitions_soak ON transitions(soak_id);
"""


class Store:
    """SQLite-backed store, safe to share across the HTTP server's threads.

    The threaded HTTP server dispatches each request on its own thread, so the
    connection is opened with ``check_same_thread=False`` and every access is
    guarded by a lock. Write volume here is tiny (a handful of soaks, periodic
    ticks), so a single serialised connection is simpler and safer than a pool
    and never becomes a bottleneck.
    """

    def __init__(self, path: str = "soak.db"):
        self.path = path
        self._lock = threading.RLock()
        self._conn = sqlite3.connect(path, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.executescript(_SCHEMA)
        self._conn.commit()

    def close(self) -> None:
        with self._lock:
            self._conn.close()

    @contextmanager
    def _tx(self) -> Iterator[sqlite3.Connection]:
        with self._lock:
            try:
                yield self._conn
                self._conn.commit()
            except Exception:
                self._conn.rollback()
                raise

    # --- soaks ----------------------------------------------------------

    def upsert_soak(self, soak: Soak) -> None:
        """Insert a soak, or leave an existing one untouched.

        Re-importing a plan must not reset a soak already in flight, so an
        existing id is preserved (its state, start time and accumulated
        telemetry stay put). Use :meth:`save_soak` to persist changes the
        engine makes.
        """
        with self._tx() as c:
            exists = c.execute("SELECT 1 FROM soaks WHERE id=?", (soak.id,)).fetchone()
            if exists:
                return
            c.execute(
                """INSERT INTO soaks
                   (id, identity_id, action, resource, condition, sources, state,
                    started_at, soak_seconds, log_coverage, min_coverage, origin, note)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    soak.id, soak.identity_id, soak.action, soak.resource,
                    soak.condition, ",".join(soak.sources), soak.state.value,
                    soak.started_at, soak.soak_seconds, soak.log_coverage,
                    soak.min_coverage, soak.origin, soak.note,
                ),
            )

    def save_soak(self, soak: Soak) -> None:
        """Persist the full current state of a soak (engine writes)."""
        with self._tx() as c:
            c.execute(
                """UPDATE soaks SET
                     identity_id=?, action=?, resource=?, condition=?, sources=?,
                     state=?, started_at=?, soak_seconds=?, log_coverage=?,
                     min_coverage=?, origin=?, note=?
                   WHERE id=?""",
                (
                    soak.identity_id, soak.action, soak.resource, soak.condition,
                    ",".join(soak.sources), soak.state.value, soak.started_at,
                    soak.soak_seconds, soak.log_coverage, soak.min_coverage,
                    soak.origin, soak.note, soak.id,
                ),
            )

    def get_soak(self, soak_id: str) -> Soak | None:
        with self._lock:
            row = self._conn.execute("SELECT * FROM soaks WHERE id=?", (soak_id,)).fetchone()
        return _row_to_soak(row) if row else None

    def list_soaks(self, state: SoakState | None = None) -> list[Soak]:
        with self._lock:
            if state is None:
                rows = self._conn.execute("SELECT * FROM soaks ORDER BY id").fetchall()
            else:
                rows = self._conn.execute(
                    "SELECT * FROM soaks WHERE state=? ORDER BY id", (state.value,)
                ).fetchall()
        return [_row_to_soak(r) for r in rows]

    def record_transition(self, soak_id: str, frm: SoakState, to: SoakState,
                          rationale: str, at: float | None = None) -> None:
        with self._tx() as c:
            c.execute(
                "INSERT INTO transitions (soak_id, from_state, to_state, rationale, at) VALUES (?,?,?,?,?)",
                (soak_id, frm.value, to.value, rationale, at or time.time()),
            )

    def transitions(self, soak_id: str) -> list[dict]:
        with self._lock:
            rows = self._conn.execute(
                "SELECT from_state, to_state, rationale, at FROM transitions WHERE soak_id=? ORDER BY id",
                (soak_id,),
            ).fetchall()
        return [dict(r) for r in rows]

    # --- events ---------------------------------------------------------

    def ingest_events(self, events: Iterable[ShadowEvent]) -> int:
        """Insert events idempotently. Returns the count newly inserted."""
        new = 0
        with self._tx() as c:
            for ev in events:
                cur = c.execute(
                    "INSERT OR IGNORE INTO events (event_id, identity_id, action, resource, timestamp) VALUES (?,?,?,?,?)",
                    (ev.event_id, ev.identity_id, ev.action, ev.resource, ev.timestamp),
                )
                new += cur.rowcount
        return new

    def events_for_identity(self, identity_id: str) -> list[ShadowEvent]:
        with self._lock:
            rows = self._conn.execute(
                "SELECT event_id, identity_id, action, resource, timestamp FROM events WHERE identity_id=?",
                (identity_id,),
            ).fetchall()
        return [
            ShadowEvent(
                identity_id=r["identity_id"], action=r["action"],
                resource=r["resource"], timestamp=r["timestamp"], event_id=r["event_id"],
            )
            for r in rows
        ]


def _row_to_soak(row: sqlite3.Row) -> Soak:
    return Soak(
        id=row["id"],
        identity_id=row["identity_id"],
        action=row["action"],
        resource=row["resource"],
        condition=row["condition"],
        sources=[s for s in (row["sources"] or "").split(",") if s],
        state=SoakState(row["state"]),
        started_at=row["started_at"],
        soak_seconds=row["soak_seconds"],
        log_coverage=row["log_coverage"],
        min_coverage=row["min_coverage"],
        origin=row["origin"],
        note=row["note"] or "",
    )
