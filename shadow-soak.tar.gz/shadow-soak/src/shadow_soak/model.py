"""Domain model for shadow-deny soaks.

A *soak* is the controlled trial a permission goes through before it is
actually revoked. The planner in ``agent-authority`` decides a permission looks
unused but can't be sure nothing depends on it, so it proposes a shadow-deny:
deny the permission *in audit-only mode*, keep serving the call, and watch for a
would-have-been-blocked event. This package runs those trials.

The one rule that makes the whole thing safe: **absence of evidence is only
evidence of absence when you were actually watching.** A soak that sees no
blocked events is "clear" *only if* telemetry covered the window. A gap in the
shadow-deny log stream must never be read as "nothing depends on this" — it
makes the soak INCONCLUSIVE, not CLEAR.
"""

from __future__ import annotations

import fnmatch
from dataclasses import dataclass, field
from enum import Enum


class SoakState(str, Enum):
    """Where a soak sits in its lifecycle."""

    PENDING = "pending"              # created, not started
    SOAKING = "soaking"             # active, window still open
    DEPENDENCY_FOUND = "dependency_found"  # a blocked event matched → real dependency
    CLEAR = "clear"                 # window done, covered, no matches → safe to revoke
    INCONCLUSIVE = "inconclusive"   # window done but telemetry coverage too low
    REVOKED = "revoked"             # operator applied the revocation (loop closed)
    RESTORED = "restored"           # dependency found → permission kept/restored
    ABORTED = "aborted"             # operator cancelled the soak

    @property
    def is_terminal(self) -> bool:
        return self in {
            SoakState.REVOKED,
            SoakState.RESTORED,
            SoakState.ABORTED,
        }

    @property
    def is_decided(self) -> bool:
        """Has evaluation reached a conclusion the operator can act on?"""
        return self in {
            SoakState.DEPENDENCY_FOUND,
            SoakState.CLEAR,
            SoakState.INCONCLUSIVE,
        }


# Allowed transitions. The engine only ever moves a soak along these edges, so
# an operator (or a bug) can't skip the trial and jump straight to REVOKED.
TRANSITIONS: dict[SoakState, set[SoakState]] = {
    SoakState.PENDING: {SoakState.SOAKING, SoakState.ABORTED},
    SoakState.SOAKING: {
        SoakState.SOAKING,           # re-evaluated, still open
        SoakState.DEPENDENCY_FOUND,
        SoakState.CLEAR,
        SoakState.INCONCLUSIVE,
        SoakState.ABORTED,
    },
    # A dependency can surface even after a window closes clear, so CLEAR and
    # INCONCLUSIVE can still fall to DEPENDENCY_FOUND on later evidence.
    SoakState.CLEAR: {
        SoakState.CLEAR,
        SoakState.DEPENDENCY_FOUND,
        SoakState.REVOKED,
        SoakState.ABORTED,
    },
    SoakState.INCONCLUSIVE: {
        SoakState.INCONCLUSIVE,
        SoakState.SOAKING,           # window extended
        SoakState.DEPENDENCY_FOUND,
        SoakState.CLEAR,
        SoakState.ABORTED,
    },
    SoakState.DEPENDENCY_FOUND: {
        SoakState.DEPENDENCY_FOUND,
        SoakState.RESTORED,
        SoakState.ABORTED,
    },
    SoakState.REVOKED: {SoakState.REVOKED},
    SoakState.RESTORED: {SoakState.RESTORED},
    SoakState.ABORTED: {SoakState.ABORTED},
}


def can_transition(src: SoakState, dst: SoakState) -> bool:
    return dst in TRANSITIONS.get(src, set())


@dataclass
class ShadowEvent:
    """A blocked-but-logged attempt recorded while a permission is shadow-denied.

    This is the critical signal: the identity tried to do something that the
    shadow-deny *would* have blocked had it been enforcing. Each one is a live
    dependency on the permission under trial.
    """

    identity_id: str
    action: str
    resource: str
    timestamp: float            # epoch seconds
    event_id: str               # provider event id, used to dedupe ingestion


@dataclass
class Soak:
    """One permission under shadow-deny trial."""

    id: str                     # stable soak id (identity + footprint hash)
    identity_id: str
    action: str                 # may contain glob wildcards
    resource: str               # may contain glob wildcards
    condition: str | None = None
    # Grant attachments to detach if this soak ends CLEAR and is revoked, and to
    # re-attach / leave in place if it ends DEPENDENCY_FOUND.
    sources: list[str] = field(default_factory=list)
    state: SoakState = SoakState.PENDING
    started_at: float | None = None
    soak_seconds: float = 14 * 86400          # default 14-day soak
    # Fraction of the soak window for which shadow-deny telemetry exists (0..1).
    # Supplied by the ingestion pipeline; low coverage blocks a CLEAR verdict.
    log_coverage: float = 1.0
    min_coverage: float = 0.9                 # coverage floor to allow CLEAR
    origin: str = "manual"                    # "manual" | "plan:<path>"
    note: str = ""

    @property
    def ends_at(self) -> float | None:
        if self.started_at is None:
            return None
        return self.started_at + self.soak_seconds

    def covers(self, action: str, resource: str) -> bool:
        """Would the soaked permission have governed this concrete call?"""
        return _glob(self.action, action) and _glob(self.resource, resource)

    def footprint(self) -> str:
        return f"{self.action} {self.resource}" + (f" if {self.condition}" if self.condition else "")


@dataclass
class Decision:
    """The outcome of evaluating a soak at a point in time."""

    soak_id: str
    state: SoakState
    rationale: str
    dependency_events: list[ShadowEvent] = field(default_factory=list)
    seconds_remaining: float | None = None


def _glob(pattern: str, value: str) -> bool:
    if pattern == "*" or pattern == value:
        return True
    return fnmatch.fnmatch(value.lower(), pattern.lower())


def soak_id_for(identity_id: str, action: str, resource: str, condition: str | None = None) -> str:
    """Deterministic soak id so re-importing the same plan is idempotent."""
    import hashlib

    raw = f"{identity_id}|{action}|{resource}|{condition or ''}"
    digest = hashlib.sha256(raw.encode()).hexdigest()[:12]
    return f"soak-{digest}"
