"""Import shadow-deny actions from an ``agent-authority`` revocation plan.

The planner in ``agent-authority`` emits JSON (``analyze --json``) whose
``actions`` list contains entries like::

    {"action": "kms:Decrypt", "resource": "arn:...", "stage": "shadow_deny",
     "sources": ["policy:key-admin"], "reason": "...", "blast_radius": "..."}

Only ``stage == "shadow_deny"`` actions become soaks here — the other stages
(monitor/alert/revoke) are handled elsewhere in the pipeline. The import is
idempotent: a stable soak id derived from the footprint means re-importing an
updated plan never duplicates or resets a soak already in flight.

This module has no import dependency on ``agent-authority`` itself — it reads
the plan as plain JSON — so the two tools stay independently installable.
"""

from __future__ import annotations

import json
from typing import Any

from .model import Soak, SoakState, soak_id_for
from .store import Store


def soaks_from_plan(
    plan: dict[str, Any],
    *,
    soak_days: float = 14.0,
    min_coverage: float = 0.9,
    origin: str = "plan",
) -> list[Soak]:
    """Build (unsaved) Soak objects from a plan dict. Pure."""
    identity_id = plan.get("identity") or plan.get("identity_id") or "unknown"
    soaks: list[Soak] = []
    for action in plan.get("actions", []):
        if action.get("stage") != "shadow_deny":
            continue
        act = action["action"]
        resource = action.get("resource", "*")
        condition = action.get("condition")
        soaks.append(
            Soak(
                id=soak_id_for(identity_id, act, resource, condition),
                identity_id=identity_id,
                action=act,
                resource=resource,
                condition=condition,
                sources=list(action.get("sources", [])),
                state=SoakState.PENDING,
                soak_seconds=soak_days * 86400,
                min_coverage=min_coverage,
                origin=origin,
                note=action.get("reason", ""),
            )
        )
    return soaks


def import_plan_file(
    store: Store,
    path: str,
    *,
    soak_days: float = 14.0,
    min_coverage: float = 0.9,
    auto_start: bool = False,
    now: float | None = None,
) -> list[Soak]:
    """Load a plan JSON file and upsert its shadow-deny actions as soaks.

    With ``auto_start`` the soaks begin immediately; otherwise they land as
    PENDING for an operator to start. Returns the soaks that were imported
    (new or already-present), reflecting their stored state.
    """
    with open(path) as fh:
        plan = json.load(fh)

    built = soaks_from_plan(
        plan, soak_days=soak_days, min_coverage=min_coverage, origin=f"plan:{path}"
    )
    result: list[Soak] = []
    for soak in built:
        store.upsert_soak(soak)
        stored = store.get_soak(soak.id)
        if stored is None:
            continue
        if auto_start and stored.state is SoakState.PENDING:
            from .engine import start_soak

            stored = start_soak(store, stored.id, now=now) or stored
        result.append(stored)
    return result
