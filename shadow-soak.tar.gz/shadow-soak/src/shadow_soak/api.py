"""Zero-dependency HTTP API + served web dashboard.

Built on ``http.server`` so the whole app runs with the standard library. The
API is small and read-mostly; the one state-changing endpoint that matters for
safety (``/api/resolve``) only accepts the operator-driven terminal moves and
still goes through the engine, so the state machine is never bypassed.

Endpoints
---------
GET  /                      → the dashboard (web/dashboard.html)
GET  /api/soaks             → all soaks (optionally ?state=soaking)
GET  /api/soaks/<id>        → one soak + its transition history
POST /api/tick             → run an evaluation cycle, return decisions
POST /api/events            → ingest shadow events (JSON list)
POST /api/start            → {"soak_id": ...} start a PENDING soak
POST /api/resolve          → {"soak_id":..., "to":"revoked|restored|aborted", "rationale":...}

This is intended for an internal operator network, not the public internet;
there is no auth layer here by design — put it behind your platform's ingress
and identity-aware proxy, as you would any internal control-plane tool.
"""

from __future__ import annotations

import json
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from .engine import resolve, start_soak, tick
from .model import ShadowEvent, Soak, SoakState
from .store import Store

_DASHBOARD = Path(__file__).parent / "web" / "dashboard.html"


def soak_to_dict(soak: Soak, now: float | None = None) -> dict:
    now = now if now is not None else time.time()
    remaining = None
    if soak.ends_at is not None:
        remaining = max(0.0, soak.ends_at - now)
    return {
        "id": soak.id,
        "identity_id": soak.identity_id,
        "action": soak.action,
        "resource": soak.resource,
        "condition": soak.condition,
        "sources": soak.sources,
        "state": soak.state.value,
        "started_at": soak.started_at,
        "ends_at": soak.ends_at,
        "seconds_remaining": remaining,
        "soak_days": round(soak.soak_seconds / 86400, 2),
        "log_coverage": soak.log_coverage,
        "min_coverage": soak.min_coverage,
        "origin": soak.origin,
        "note": soak.note,
        "footprint": soak.footprint(),
    }


class _Handler(BaseHTTPRequestHandler):
    # Injected by make_server.
    store: Store = None  # type: ignore[assignment]

    def log_message(self, *args):  # quieter default logging
        pass

    def _send(self, code: int, payload, content_type="application/json"):
        if content_type == "application/json":
            body = json.dumps(payload, indent=2).encode()
        else:
            body = payload if isinstance(payload, bytes) else str(payload).encode()
        self.send_response(code)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _read_json(self):
        length = int(self.headers.get("Content-Length", 0))
        if not length:
            return None
        raw = self.rfile.read(length)
        return json.loads(raw)

    # --- routing --------------------------------------------------------

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path
        if path == "/" or path == "/index.html":
            if _DASHBOARD.exists():
                self._send(200, _DASHBOARD.read_bytes(), "text/html; charset=utf-8")
            else:
                self._send(200, "<h1>shadow-soak</h1><p>dashboard missing</p>", "text/html")
            return
        if path == "/api/soaks":
            qs = parse_qs(parsed.query)
            state = None
            if "state" in qs:
                try:
                    state = SoakState(qs["state"][0])
                except ValueError:
                    self._send(400, {"error": f"unknown state {qs['state'][0]}"})
                    return
            soaks = self.store.list_soaks(state)
            self._send(200, {"soaks": [soak_to_dict(s) for s in soaks]})
            return
        if path.startswith("/api/soaks/"):
            soak_id = path.rsplit("/", 1)[-1]
            soak = self.store.get_soak(soak_id)
            if not soak:
                self._send(404, {"error": "not found"})
                return
            self._send(200, {
                "soak": soak_to_dict(soak),
                "transitions": self.store.transitions(soak_id),
            })
            return
        self._send(404, {"error": "not found"})

    def do_POST(self):
        path = urlparse(self.path).path
        try:
            if path == "/api/tick":
                decisions = tick(self.store)
                self._send(200, {"decisions": [
                    {"soak_id": d.soak_id, "state": d.state.value,
                     "rationale": d.rationale,
                     "dependency_events": len(d.dependency_events)}
                    for d in decisions
                ]})
                return
            if path == "/api/events":
                body = self._read_json() or []
                events = [
                    ShadowEvent(
                        identity_id=e["identity_id"], action=e["action"],
                        resource=e["resource"], timestamp=float(e["timestamp"]),
                        event_id=e["event_id"],
                    )
                    for e in body
                ]
                new = self.store.ingest_events(events)
                self._send(200, {"ingested": new, "received": len(events)})
                return
            if path == "/api/start":
                body = self._read_json() or {}
                soak = start_soak(self.store, body["soak_id"])
                if not soak:
                    self._send(404, {"error": "not found"})
                    return
                self._send(200, {"soak": soak_to_dict(soak)})
                return
            if path == "/api/resolve":
                body = self._read_json() or {}
                to = SoakState(body["to"])
                if to not in {SoakState.REVOKED, SoakState.RESTORED, SoakState.ABORTED}:
                    self._send(400, {"error": "resolve only accepts revoked|restored|aborted"})
                    return
                soak = resolve(self.store, body["soak_id"], to,
                               body.get("rationale", "operator resolution"))
                if not soak:
                    self._send(404, {"error": "not found"})
                    return
                self._send(200, {"soak": soak_to_dict(soak)})
                return
            self._send(404, {"error": "not found"})
        except (KeyError, ValueError) as exc:
            self._send(400, {"error": str(exc)})


def make_server(store: Store, host: str = "127.0.0.1", port: int = 8787) -> ThreadingHTTPServer:
    handler = type("BoundHandler", (_Handler,), {"store": store})
    return ThreadingHTTPServer((host, port), handler)


def serve(store: Store, host: str = "127.0.0.1", port: int = 8787) -> None:
    server = make_server(store, host, port)
    print(f"shadow-soak dashboard on http://{host}:{port}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        server.shutdown()
