"""Command-line interface.

    shadow-soak import-plan PLAN.json [--start] [--soak-days 14] [--db soak.db]
    shadow-soak ingest EVENTS.json [--db soak.db]
    shadow-soak coverage SOAK_ID 0.95 [--db soak.db]
    shadow-soak start SOAK_ID [--db soak.db]
    shadow-soak tick [--db soak.db]
    shadow-soak status [--state soaking] [--db soak.db]
    shadow-soak resolve SOAK_ID revoked|restored|aborted [--note ...] [--db soak.db]
    shadow-soak serve [--host 127.0.0.1] [--port 8787] [--db soak.db]

EVENTS.json is a list of shadow events::

    [{"identity_id":"...","action":"...","resource":"...","timestamp":<epoch>,"event_id":"..."}]
"""

from __future__ import annotations

import argparse
import json
import sys

from .model import ShadowEvent, SoakState
from .store import Store
from .engine import resolve, set_coverage, start_soak, tick
from .importer import import_plan_file
from .api import serve


def _p(soak) -> str:
    rem = ""
    if soak.state is SoakState.SOAKING and soak.ends_at is not None:
        import time
        rem = f"  ({max(0.0, (soak.ends_at - time.time()) / 86400):.1f}d left)"
    return (f"[{soak.state.value:>16}] {soak.id}  {soak.footprint()}"
            f"  cov={soak.log_coverage:.0%}{rem}")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="shadow-soak")
    parser.add_argument("--db", default="soak.db", help="SQLite path (default soak.db)")
    sub = parser.add_subparsers(dest="cmd", required=True)

    pi = sub.add_parser("import-plan", help="import shadow_deny actions from an agent-authority plan")
    pi.add_argument("plan")
    pi.add_argument("--start", action="store_true", help="start the soaks immediately")
    pi.add_argument("--soak-days", type=float, default=14.0)
    pi.add_argument("--min-coverage", type=float, default=0.9)

    ig = sub.add_parser("ingest", help="ingest shadow events (blocked-but-logged)")
    ig.add_argument("events")

    cv = sub.add_parser("coverage", help="set telemetry coverage for a soak")
    cv.add_argument("soak_id")
    cv.add_argument("value", type=float)

    st = sub.add_parser("start", help="start a PENDING soak")
    st.add_argument("soak_id")

    sub.add_parser("tick", help="run one evaluation cycle")

    ss = sub.add_parser("status", help="list soaks")
    ss.add_argument("--state", default=None)

    rs = sub.add_parser("resolve", help="operator terminal move")
    rs.add_argument("soak_id")
    rs.add_argument("to", choices=["revoked", "restored", "aborted"])
    rs.add_argument("--note", default="operator resolution")

    sv = sub.add_parser("serve", help="run the HTTP API + dashboard")
    sv.add_argument("--host", default="127.0.0.1")
    sv.add_argument("--port", type=int, default=8787)

    args = parser.parse_args(argv)
    store = Store(args.db)

    if args.cmd == "import-plan":
        soaks = import_plan_file(
            store, args.plan, soak_days=args.soak_days,
            min_coverage=args.min_coverage, auto_start=args.start,
        )
        print(f"Imported {len(soaks)} shadow-deny soak(s) from {args.plan}:")
        for s in soaks:
            print("  " + _p(s))
        if not args.start and soaks:
            print("\nStart them with `shadow-soak start <id>` (or re-import with --start).")
        return 0

    if args.cmd == "ingest":
        with open(args.events) as fh:
            rows = json.load(fh)
        events = [
            ShadowEvent(
                identity_id=r["identity_id"], action=r["action"], resource=r["resource"],
                timestamp=float(r["timestamp"]), event_id=r["event_id"],
            )
            for r in rows
        ]
        new = store.ingest_events(events)
        print(f"Ingested {new} new event(s) ({len(events) - new} already seen).")
        return 0

    if args.cmd == "coverage":
        soak = set_coverage(store, args.soak_id, args.value)
        print(_p(soak) if soak else "soak not found")
        return 0 if soak else 1

    if args.cmd == "start":
        soak = start_soak(store, args.soak_id)
        print(_p(soak) if soak else "soak not found")
        return 0 if soak else 1

    if args.cmd == "tick":
        decisions = tick(store)
        if not decisions:
            print("No active soaks to evaluate.")
        for d in decisions:
            print(f"[{d.state.value:>16}] {d.soak_id}  {d.rationale}")
        return 0

    if args.cmd == "status":
        state = SoakState(args.state) if args.state else None
        soaks = store.list_soaks(state)
        if not soaks:
            print("No soaks.")
        for s in soaks:
            print(_p(s))
        return 0

    if args.cmd == "resolve":
        soak = resolve(store, args.soak_id, SoakState(args.to), args.note)
        print(_p(soak) if soak else "soak not found")
        return 0 if soak else 1

    if args.cmd == "serve":
        serve(store, args.host, args.port)
        return 0

    return 1


if __name__ == "__main__":
    sys.exit(main())
