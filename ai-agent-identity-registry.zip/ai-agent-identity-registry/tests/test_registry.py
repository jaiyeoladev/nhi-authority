import json,tempfile,unittest,threading,urllib.request,urllib.error
from pathlib import Path
from datetime import date,timedelta
from registry import Registry,flags
from app import make_server
class Tests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.path=Path(self.tmp.name)/'test.sqlite3';self.db=Registry(self.path);self.agent=json.loads((Path(__file__).parents[1]/'examples/demo.json').read_text())[0]
 def tearDown(self):self.tmp.cleanup()
 def test_persistence(self):
  r=self.db.save(self.agent);self.assertEqual(Registry(self.path).list()[0]['id'],r['id']);self.assertEqual(len(self.db.history()),1)
 def test_update_and_snapshots(self):
  r=self.db.save(self.agent);d=dict(self.agent,owner='New owner');self.db.save(d,r['id'],r['version']);h=self.db.history()[0];self.assertEqual(json.loads(h['before'])['owner'],self.agent['owner']);self.assertEqual(json.loads(h['after'])['owner'],'New owner')
 def test_conflict(self):
  r=self.db.save(self.agent);self.db.save(self.agent,r['id'],1)
  with self.assertRaises(ValueError):self.db.save(self.agent,r['id'],1)
 def test_invalid_import_atomic(self):
  with self.assertRaises(ValueError):self.db.import_agents([self.agent,{}])
  self.assertEqual(self.db.list(),[]);self.assertEqual(self.db.history(),[])
 def test_import_ignores_review_claim(self):
  self.db.import_agents([dict(self.agent,last_reviewed='fake',id='fake')]);r=self.db.list()[0];self.assertNotEqual(r['id'],'fake');self.assertNotIn('last_reviewed',r)
 def test_review_note_required(self):
  with self.assertRaises(ValueError):self.db.save(self.agent,review_note='')
 def test_review_future_required(self):
  with self.assertRaises(ValueError):self.db.save(self.agent,review_note='Checked')
 def test_review_recorded(self):
  d=dict(self.agent,review_due=(date.today()+timedelta(days=30)).isoformat());r=self.db.save(d,review_note='Owner confirmed scope');self.assertIn('last_reviewed',r);self.assertEqual(self.db.history()[0]['action'],'review')
 def test_flags(self):
  d=dict(self.agent,owner='',permissions='*',dependencies='');self.assertEqual(len(flags(d,'2026-10-21')),4)
 def test_retired_not_overdue(self):self.assertNotIn('Review overdue',flags(dict(self.agent,status='retired'),'2026-10-21'))
 def test_missing_record(self):
  with self.assertRaises(LookupError):self.db.save(self.agent,'missing',1)
 def test_validation(self):
  for d in [None,dict(self.agent,provider='bad'),dict(self.agent,review_due='bad'),dict(self.agent,name=3)]:
   with self.assertRaises(ValueError):self.db.save(d)
 def test_http_controls(self):
  s=make_server(0,self.path);t=threading.Thread(target=s.serve_forever,daemon=True);t.start();base='http://127.0.0.1:'+str(s.server_port)
  try:
   for route in ['/','/app.js','/style.css','/api/demo']:self.assertEqual(urllib.request.urlopen(base+route).status,200)
   state=json.load(urllib.request.urlopen(base+'/api/state'));self.assertIn('token',state)
   body=json.dumps({'agent':self.agent}).encode()
   for token,origin,expected in [('',None,403),(state['token'],'https://bad.example',403),(state['token'],None,200)]:
    headers={'X-Registry-Token':token}
    if origin:headers['Origin']=origin
    request=urllib.request.Request(base+'/api/save',data=body,headers=headers)
    try:self.assertEqual(urllib.request.urlopen(request).status,expected)
    except urllib.error.HTTPError as e:self.assertEqual(e.code,expected)
  finally:s.shutdown();s.server_close();t.join()
if __name__=='__main__':unittest.main()
