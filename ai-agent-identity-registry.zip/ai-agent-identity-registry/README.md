# AI Agent Identity Registry

A runnable local application for recording non-human and AI agent identities, ownership, declared authority, dependent workloads and access reviews.

This companion to Agent Authority Mapper addresses the inventory and accountability stage of dependency-aware authority research. It does not compute effective cloud authorization or revoke permissions.

## Start

Requires Python 3.11 or later, with no third-party dependencies or cloud account.

```bash
python app.py
```

Open http://127.0.0.1:8090. On Windows, `py app.py` also works. Click **Add demo records** to load three fictional identities. Demo loading is additive, so repeated clicks create additional records.

Optional port and database:

```bash
python app.py --port 8091 --db data/my-registry.sqlite3
```

## Features

* Register and edit agent identities across AWS, Azure, GCP and other platforms.
* Record accountable owner, cloud identity reference, purpose and lifecycle status.
* Document declared permissions and dependent workloads as plain text.
* Filter by lifecycle status or attention flags, and search names, owners and identity references.
* Flag missing owners, overdue reviews, wildcard declarations and undocumented dependencies.
* Complete a review with an evidence note and future next-review date.
* Persist records in SQLite with transactional before and after history.
* Prevent stale edits through optimistic version checks.
* Import up to 100 JSON records atomically, as new unverified declarations.
* Export all current identities and up to 500 most recent history events.

The database is created in `data/` on first run and excluded from Git. Copy the database while the app is stopped for a consistent local backup. Permissions and notes may contain sensitive details, so review exports before sharing.

## Typical workflow

1. Register a machine or agent identity and its owner.
2. Describe its purpose, declared permissions and known dependent workloads.
3. Investigate attention flags with the workload owner.
4. Update the record, select completed review, add evidence and set a future date.
5. Export a research snapshot for further analysis.

Marking an identity paused or retired updates this inventory only. It does not disable or remove the cloud identity. A completed review is a local user declaration, not an independently verified approval.

## API

`GET /api/state` returns agents, calculated flags, latest 500 history events and a per-process mutation token. `GET /api/demo` returns synthetic inputs. POST requests require `X-Registry-Token` from state. The server checks host and same-origin browser requests.

`POST /api/save`: `{"agent": {...}}` creates a record. Add `id` and integer `version` to update. Add nonempty `review_note` to record a completed review; next review must be in the future.

`POST /api/import` takes an array of 1 to 100 agents. All validate before any write. Export envelopes with `agents` are accepted by the browser import interface. Imports create new records, discard IDs, versions and review claims, and do not restore audit history.

Required record fields: `name`, `provider`, `identity_ref`, `purpose`, `status`, `review_due`. Optional text fields: `owner`, `permissions`, `dependencies`, `notes`. Provider values: AWS, Azure, GCP, Other. Status values: active, paused, retired. Use ISO dates, YYYY-MM-DD. Every field is limited to 10000 characters. Body limit: 1 MB.

## Test

```bash
python -m unittest discover -s tests -v
```

GitHub Actions runs checks on Python 3.11, 3.12 and 3.13.

## Upload to GitHub

Extract this archive, create an empty GitHub repository named `ai-agent-identity-registry`, then run inside the extracted folder:

```bash
git init
git add .
git commit -m "Add AI agent identity registry research application"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/ai-agent-identity-registry.git
git push -u origin main
```

Replace YOUR_USERNAME. Alternatively use GitHub's file upload interface. GitHub Pages cannot run this Python backend. No live site is published by this package.

## Scope and security

[Design and research context](docs/DESIGN.md), [security notes](SECURITY.md).

Local single-user prototype, no authentication, cloud discovery or authorization enforcement. The audit history is not tamper evident. Do not expose the server to an untrusted network or put secrets into records. Flags are simple inventory heuristics, not a security score or complete privilege evaluation.

## License

MIT. Select an appropriate publication and licensing approach before public release.
