# Security

This is a trusted local, single-user research application. It binds only to 127.0.0.1. It has no login, role-based access controls, encryption at rest or production hosting configuration.

HTTP mutations require a random per-process token; Host and browser Origin checks reduce cross-site and DNS-rebinding exposure. The browser renders untrusted fields using textContent. A Content Security Policy restricts scripts and framing. SQL values are parameterized, imports validate before committing, and updates use record versions. These controls do not protect against a malicious local user, compromised browser extension or an administrator who can change the database.

Do not enter passwords, tokens or private keys. Limit access to the computer and database. Exports may contain sensitive workload structure and notes. The audit log records no authenticated actor and is not tamper evident. Public reporting must not include private snapshots. Enable GitHub private vulnerability reporting or provide a verified private contact before inviting sensitive reports.
