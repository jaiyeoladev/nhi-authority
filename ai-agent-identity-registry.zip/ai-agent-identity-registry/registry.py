"""Local SQLite identity inventory and declared dependency records."""
import json
import sqlite3
import uuid
from datetime import date,datetime,timezone

def today():return date.today().isoformat()
def now():return datetime.now(timezone.utc).isoformat()
def validate(d):
 if not isinstance(d,dict):raise ValueError('Agent must be a JSON object')
 result={}
 for key in ['name','owner','provider','identity_ref','purpose','status','review_due','permissions','dependencies','notes']:
  v=d.get(key,'')
  if not isinstance(v,str) or len(v)>10000:raise ValueError(key+' must be text up to 10000 characters')
  result[key]=v.strip()
 for key in ['name','provider','identity_ref','purpose','review_due']:
  if not result[key]:raise ValueError(key+' is required')
 if result['provider'] not in ['AWS','Azure','GCP','Other']:raise ValueError('Invalid provider')
 if result['status'] not in ['active','paused','retired']:raise ValueError('Invalid status')
 try:date.fromisoformat(result['review_due'])
 except ValueError:raise ValueError('Review due must be an ISO date')
 return result

def flags(d,on=None):
 on=on or today();f=[]
 if not d['owner']:f.append('Owner missing')
 if d['status']!='retired' and d['review_due']<on:f.append('Review overdue')
 if '*' in d['permissions']:f.append('Wildcard declared')
 if not d['dependencies']:f.append('Dependencies undocumented')
 return f

class Registry:
 def __init__(self,path):
  self.path=str(path)
  with self.connect() as c:
   c.executescript("""CREATE TABLE IF NOT EXISTS agents(id TEXT PRIMARY KEY,version INTEGER NOT NULL,data TEXT NOT NULL);
   CREATE TABLE IF NOT EXISTS audit(seq INTEGER PRIMARY KEY AUTOINCREMENT,time TEXT NOT NULL,agent_id TEXT NOT NULL,action TEXT NOT NULL,before_json TEXT,after_json TEXT,note TEXT NOT NULL);""")
 def connect(self):return sqlite3.connect(self.path,timeout=10)
 def list(self):
  with self.connect() as c:return [dict(json.loads(d),id=i,version=v) for i,v,d in c.execute('SELECT id,version,data FROM agents ORDER BY rowid DESC')]
 def history(self):
  with self.connect() as c:return [dict(zip(['sequence','time','agent_id','action','before','after','note'],row)) for row in c.execute('SELECT * FROM audit ORDER BY seq DESC LIMIT 500')]
 def save(self,data,agent_id=None,version=None,review_note=None):
  d=validate(data)
  if review_note is not None:
   if not isinstance(review_note,str) or not review_note.strip() or len(review_note)>2000:raise ValueError('Review evidence note is required (up to 2000 characters)')
   if d['review_due']<=today():raise ValueError('Next review date must be in the future')
   d['last_reviewed']=now()
  with self.connect() as c:
   c.execute('BEGIN IMMEDIATE')
   old=None
   if agent_id:
    row=c.execute('SELECT version,data FROM agents WHERE id=?',(agent_id,)).fetchone()
    if not row:raise LookupError('Agent not found')
    if type(version)!=int or version!=row[0]:raise ValueError('Record changed. Refresh before saving.')
    old=row[1]; prior=json.loads(old)
    if review_note is None and prior.get('last_reviewed'):d['last_reviewed']=prior['last_reviewed']
    version+=1
    c.execute('UPDATE agents SET version=?,data=? WHERE id=?',(version,json.dumps(d),agent_id))
   else:
    agent_id=str(uuid.uuid4());version=1
    c.execute('INSERT INTO agents VALUES(?,?,?)',(agent_id,version,json.dumps(d)))
   c.execute('INSERT INTO audit(time,agent_id,action,before_json,after_json,note) VALUES(?,?,?,?,?,?)',(now(),agent_id,'review' if review_note is not None else 'update' if old else 'create',old,json.dumps(d),review_note or 'Local user change'))
  return dict(d,id=agent_id,version=version)
 def import_agents(self,items):
  if not isinstance(items,list) or not 1<=len(items)<=100:raise ValueError('Import must contain 1 to 100 agents')
  # Validate all before opening transaction; ignore imported IDs and review claims.
  records=[validate(d) for d in items]
  with self.connect() as c:
   c.execute('BEGIN IMMEDIATE')
   for d in records:
    i=str(uuid.uuid4());s=json.dumps(d)
    c.execute('INSERT INTO agents VALUES(?,?,?)',(i,1,s))
    c.execute('INSERT INTO audit(time,agent_id,action,after_json,note) VALUES(?,?,?,?,?)',(now(),i,'import',s,'Imported unverified declaration'))
  return len(records)
