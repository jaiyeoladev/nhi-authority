# Design and research context

## Contribution to the proposed endeavour

Computing authority requires a reliable identity inventory and context about dependent systems. This application records those declarations and preserves changes for reproducible follow-up. It supports the input and governance stage of the research, rather than claiming to solve effective-access computation or safe revocation.

## Architecture

The browser uses a Python standard-library HTTP API on loopback. A SQLite database stores agent documents, versions and local change history. Validation happens on the server. Mutations and associated history are committed in one database transaction. Version checks stop one editor overwriting changes made by another editor with an older snapshot.

## Data provenance

Every record is user-entered or imported. Identity references are labels and are not authenticated against a provider. Owners and review notes are not identity-verified. Permission and dependency fields are plain text, with no policy evaluation. An export includes current records and at most 500 recent history entries. The database retains all history unless modified by an administrator.

## Attention rules

| Flag | Rule | Interpretation |
| --- | --- | --- |
| Owner missing | Owner text is empty | Accountability needs investigation |
| Review overdue | Review date is before the local server date and status is not retired | Review needs scheduling |
| Wildcard declared | Permission text contains an asterisk | Broad-looking declaration needs inspection |
| Dependencies undocumented | Dependency text is empty | Workload evidence is missing |

A review due today is not yet overdue. The rules use the server's local calendar date, which should be configured appropriately. Wildcards can be legitimate and string detection alone does not establish overprivilege. Records with no flags can still hold excessive authority.

## Lifecycle and reviews

Active, paused and retired are inventory states only. A completed review requires a note and a next-review date after today. The server records its own timestamp. This is a local assertion, not a formal or authenticated approval workflow.

## Evaluation opportunities

Measure inventory completeness against cloud-discovered identities, owner-attribution accuracy, dependency-evidence coverage, review completion and false-positive rates for attention flags. These experiments have not been conducted in this repository. Future work could link authenticated evidence snapshots to the authority analyser and add live sandbox validation before any revocation proposal.
