import argparse,json,secrets
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
from registry import Registry,flags,today
ROOT=Path(__file__).parent
class Handler(BaseHTTPRequestHandler):
 def send(self,status,data,kind='application/json'):
  body=data if isinstance(data,bytes) else json.dumps(data).encode()
  self.send_response(status)
  for k,v in {'Content-Type':kind+'; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Content-Security-Policy':"default-src 'self'; script-src 'self'; style-src 'self'; object-src 'none'; frame-ancestors 'none'; base-uri 'none'"}.items():self.send_header(k,v)
  self.end_headers();self.wfile.write(body)
 def valid_host(self):return self.headers.get('Host') in {f'127.0.0.1:{self.server.server_port}',f'localhost:{self.server.server_port}'}
 def do_GET(self):
  if not self.valid_host():return self.send(403,{'error':'Invalid host'})
  routes={'/':('index.html','text/html'),'/app.js':('app.js','text/javascript'),'/style.css':('style.css','text/css')}
  if self.path in routes:
   n,t=routes[self.path];return self.send(200,(ROOT/'static'/n).read_bytes(),t)
  if self.path=='/api/state':return self.send(200,{'agents':[dict(d,flags=flags(d)) for d in self.server.db.list()],'audit':self.server.db.history(),'token':self.server.token,'today':today()})
  if self.path=='/api/demo':return self.send(200,json.loads((ROOT/'examples/demo.json').read_text()))
  self.send(404,{'error':'Not found'})
 def do_POST(self):
  if not self.valid_host() or self.headers.get('X-Registry-Token')!=self.server.token:return self.send(403,{'error':'Refresh this page before making changes'})
  origin=self.headers.get('Origin')
  if origin and origin!='http://'+self.headers.get('Host'):return self.send(403,{'error':'Cross-origin request rejected'})
  try:
   n=int(self.headers.get('Content-Length','0'))
   if not 0<n<=1000000:raise ValueError('Request must be 1 byte to 1 MB')
   d=json.loads(self.rfile.read(n))
   if self.path=='/api/import':return self.send(200,{'imported':self.server.db.import_agents(d)})
   if self.path=='/api/save':
    if not isinstance(d,dict):raise ValueError('Expected an object')
    return self.send(200,self.server.db.save(d.get('agent'),d.get('id'),d.get('version'),d.get('review_note')))
   self.send(404,{'error':'Not found'})
  except LookupError as e:self.send(404,{'error':str(e)})
  except (ValueError,TypeError,RecursionError) as e:self.send(400,{'error':str(e)})
def make_server(port,db_path):
 s=ThreadingHTTPServer(('127.0.0.1',port),Handler);s.db=Registry(db_path);s.token=secrets.token_urlsafe(32);return s
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--port',type=int,default=8090);p.add_argument('--db',default=str(ROOT/'data/registry.sqlite3'));a=p.parse_args()
 Path(a.db).parent.mkdir(parents=True,exist_ok=True)
 s=make_server(a.port,a.db);print(f'Open http://127.0.0.1:{s.server_port}',flush=True);s.serve_forever()
