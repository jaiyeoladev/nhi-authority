import time

from agent_authority import (
    BindingKind, Grant, Identity, IdentityType, Permission, Policy,
    AccessEvent, resolve_effective_authority, summarise_usage,
    score_identity, build_report, Verdict, unmet_demand,
)


def _agent(perms):
    grants = [Grant(Policy(f"p{i}", [p]), source=f"policy:p{i}")
              for i, p in enumerate(perms)]
    return Identity(id="a", name="a", type=IdentityType.AI_AGENT, grants=grants)


def test_used_permission_scored_used():
    now = time.time()
    agent = _agent([Permission("s3:GetObject", "b/*")])
    auth = resolve_effective_authority(agent)
    events = [AccessEvent("a", "s3:GetObject", "b/file", now - 86400)]
    obs = summarise_usage("a", events, now - 90 * 86400, now)
    findings = score_identity(auth, obs)
    assert findings[0].verdict is Verdict.USED
    assert findings[0].revocation_confidence == 0.0


def test_unused_long_window_high_confidence():
    now = time.time()
    agent = _agent([Permission("s3:DeleteObject", "b/*")])
    auth = resolve_effective_authority(agent)
    obs = summarise_usage("a", [], now - 90 * 86400, now, log_coverage=1.0)
    findings = score_identity(auth, obs)
    assert findings[0].verdict is Verdict.UNUSED
    assert findings[0].revocation_confidence >= 0.6


def test_unused_short_window_is_uncertain():
    now = time.time()
    agent = _agent([Permission("s3:DeleteObject", "b/x")])
    auth = resolve_effective_authority(agent)
    obs = summarise_usage("a", [], now - 3 * 86400, now, log_coverage=1.0)
    findings = score_identity(auth, obs)
    assert findings[0].verdict is Verdict.UNCERTAIN


def test_low_coverage_lowers_confidence():
    now = time.time()
    agent = _agent([Permission("s3:DeleteObject", "b/x")])
    auth = resolve_effective_authority(agent)
    full = score_identity(auth, summarise_usage("a", [], now - 90 * 86400, now, 1.0))[0]
    poor = score_identity(auth, summarise_usage("a", [], now - 90 * 86400, now, 0.2))[0]
    assert poor.revocation_confidence < full.revocation_confidence


def test_wildcard_used_if_any_covered_call_seen():
    now = time.time()
    agent = _agent([Permission("s3:*", "b/*")])
    auth = resolve_effective_authority(agent)
    events = [AccessEvent("a", "s3:GetObject", "b/file", now - 86400)]
    obs = summarise_usage("a", events, now - 90 * 86400, now)
    assert score_identity(auth, obs)[0].verdict is Verdict.USED


def test_report_ratio_and_unmet_demand():
    now = time.time()
    agent = _agent([Permission("s3:GetObject", "b/*"),
                    Permission("s3:DeleteObject", "b/*")])
    auth = resolve_effective_authority(agent)
    events = [
        AccessEvent("a", "s3:GetObject", "b/file", now - 86400),
        AccessEvent("a", "sns:Publish", "topic", now - 86400, outcome="denied"),
    ]
    obs = summarise_usage("a", events, now - 90 * 86400, now)
    report = build_report(score_identity(auth, obs), "a")
    assert report.used == 1
    assert 0 < report.over_privilege_ratio <= 1
    assert any(f.action == "sns:Publish" for f in unmet_demand(obs))
