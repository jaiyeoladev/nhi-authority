from agent_authority import (
    BindingKind, Effect, Grant, Identity, IdentityType, Permission, Policy,
    resolve_effective_authority, authority_breadth,
)


def _identity(grants, tags=None):
    return Identity(id="id1", name="t", type=IdentityType.AI_AGENT,
                    grants=grants, tags=tags or {})


def test_allow_flattens_with_provenance():
    g1 = Grant(Policy("a", [Permission("s3:GetObject", "b/*")]), source="policy:a")
    g2 = Grant(Policy("b", [Permission("s3:GetObject", "b/*")]), source="policy:b")
    auth = resolve_effective_authority(_identity([g1, g2]))
    assert len(auth.permissions) == 1
    # Both grants recorded as sources of the merged footprint.
    assert auth.permissions[0].sources == frozenset({"policy:a", "policy:b"})


def test_explicit_deny_overrides_allow():
    allow = Grant(Policy("a", [Permission("s3:GetObject", "secret/*")]), source="policy:a")
    deny = Grant(Policy("d", [Permission("s3:GetObject", "secret/*", effect=Effect.DENY)]),
                 source="policy:d")
    auth = resolve_effective_authority(_identity([allow, deny]))
    assert auth.permissions == []


def test_wildcard_deny_shadows_specific_allow():
    allow = Grant(Policy("a", [Permission("s3:GetObject", "secret/file")]), source="policy:a")
    deny = Grant(Policy("d", [Permission("s3:*", "secret/*", effect=Effect.DENY)]),
                 source="policy:d")
    auth = resolve_effective_authority(_identity([allow, deny]))
    assert auth.permissions == []


def test_boundary_caps_allow():
    # Policy allows s3:* but the boundary only permits GetObject.
    boundary = Policy("bound", [Permission("s3:GetObject", "*")])
    g = Grant(Policy("a", [Permission("s3:DeleteObject", "b/*")]),
              source="policy:a", boundary=boundary)
    auth = resolve_effective_authority(_identity([g]))
    # DeleteObject is outside the boundary → not effective.
    assert auth.permissions == []


def test_boundary_allows_within():
    boundary = Policy("bound", [Permission("s3:*", "*")])
    g = Grant(Policy("a", [Permission("s3:GetObject", "b/*")]),
              source="policy:a", boundary=boundary)
    auth = resolve_effective_authority(_identity([g]))
    assert len(auth.permissions) == 1


def test_breadth_scores_wildcards_higher():
    narrow = resolve_effective_authority(_identity(
        [Grant(Policy("n", [Permission("s3:GetObject", "b/x")]), source="n")]))
    broad = resolve_effective_authority(_identity(
        [Grant(Policy("w", [Permission("s3:*", "*")]), source="w")]))
    assert authority_breadth(broad) > authority_breadth(narrow)
