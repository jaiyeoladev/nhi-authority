import time

from agent_authority import (
    BindingKind, Grant, Identity, IdentityType, Permission, Policy,
    AccessEvent, resolve_effective_authority, summarise_usage,
    score_identity, PlannerConfig, plan_revocation, Stage, render_plan,
)


def _plan(perms, tags=None, events=None, soaked=frozenset(), window=90):
    now = time.time()
    grants = []
    for i, p in enumerate(perms):
        enables = ["role:other"] if p.action == "sts:AssumeRole" else []
        grants.append(Grant(Policy(f"p{i}", [p]), source=f"policy:p{i}",
                            binding=BindingKind.DIRECT, enables=enables))
    agent = Identity(id="a", name="a", type=IdentityType.AI_AGENT,
                     grants=grants, tags=tags or {})
    auth = resolve_effective_authority(agent)
    obs = summarise_usage("a", events or [], now - window * 86400, now)
    findings = score_identity(auth, obs)
    return plan_revocation(agent, findings, PlannerConfig(soaked_sources=soaked))


def test_used_permission_never_in_plan():
    now = time.time()
    events = [AccessEvent("a", "s3:GetObject", "b/file", now - 86400)]
    plan = _plan([Permission("s3:GetObject", "b/*")], events=events)
    assert plan.actions == []


def test_protected_grant_only_monitored():
    plan = _plan(
        [Permission("s3:PutObject", "restore/*")],
        tags={"protect": "policy:p0"},
    )
    assert len(plan.actions) == 1
    assert plan.actions[0].stage is Stage.MONITOR
    assert plan.actions[0].protected_by


def test_uncertain_goes_to_alert_not_revoke():
    # Short window → uncertain → ALERT regardless of soak.
    plan = _plan([Permission("s3:DeleteObject", "b/x")],
                 window=3, soaked=frozenset({"policy:p0"}))
    assert plan.actions[0].stage is Stage.ALERT


def test_narrow_unused_soaks_then_revokes():
    perm = [Permission("s3:DeleteObject", "b/specific")]
    first = _plan(perm)  # nothing soaked
    assert first.actions[0].stage is Stage.SHADOW_DENY
    second = _plan(perm, soaked=frozenset({"policy:p0"}))
    assert second.actions[0].stage is Stage.REVOKE


def test_critical_action_held_at_shadow_until_soaked():
    perm = [Permission("kms:ScheduleKeyDeletion", "*")]
    first = _plan(perm)
    assert first.actions[0].stage is Stage.SHADOW_DENY
    assert "critical" in first.actions[0].blast_radius.lower()
    second = _plan(perm, soaked=frozenset({"policy:p0"}))
    assert second.actions[0].stage is Stage.REVOKE


def test_enabling_grant_reports_blast_radius():
    plan = _plan([Permission("sts:AssumeRole", "arn:aws:iam::*:role/x")])
    assert "enables" in plan.actions[0].blast_radius.lower()


def test_render_plan_is_stringable():
    plan = _plan([Permission("s3:DeleteObject", "b/x")])
    text = render_plan(plan)
    assert "Revocation plan" in text
    assert "detach" in text
