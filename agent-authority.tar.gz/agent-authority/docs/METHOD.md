# Method: Computing and Safely Reducing the Effective Authority of Non-Human and AI-Agent Identities

> A method for computing the *actual* scope of authority held by non-human and
> AI-agent identities in cloud environments, and for safely revoking excess
> authority without disrupting dependent systems.

Non-human identities (NHIs) — service principals, managed identities, service
accounts, workload roles — now outnumber human identities in most cloud
estates by a wide margin, and autonomous AI agents add a new class that
acquires tools and permissions dynamically. They are routinely over-provisioned
because (a) coarse wildcard grants are the path of least resistance, (b) nobody
is sure what will break if a permission is removed, and (c) there is no human
to notice an unused entitlement. The result is large, silent blast radius.

This method has three stages: **compute effective authority**, **measure
over-privilege against observed usage**, and **plan revocation that is staged,
reversible, and dependency-aware.** Each is implemented in the reference code
alongside this document.

---

## 1. Compute effective authority

"What is this identity attached to?" is the wrong question. The right one is
"what can this identity actually do *right now*?" Those differ because of three
mechanisms every mature IAM engine enforces:

1. **Explicit deny overrides allow.** One matching deny defeats any number of
   allows across the same footprint.
2. **Permission boundaries / SCPs cap grants.** An action is effective only
   where it is allowed by a policy *and* permitted by the enclosing boundary.
3. **Inheritance.** Authority arrives directly, through group / directory-role
   membership, through assumable roles, and down a resource-scope hierarchy.

**Effective authority** is therefore the deny-aware, boundary-capped flattening
of every grant an identity reaches, expressed as a set of
`(action, resource, condition)` atoms — each annotated with the **provenance**
of every grant that produced it. Provenance is not optional: remediation that
can say "this permission is excess" but not "detach *these three* attachments to
remove it" cannot be executed safely.

The resolver does not expand wildcards into a provider's full action catalogue.
It keeps grants at their stated granularity and compares by glob match. This
keeps the method cloud-agnostic and avoids inventing actions a provider may not
have. A wildcard's reach is instead captured by a **breadth score** so that a
`*:*` identity ranks as high latent risk regardless of its logs.

*Implemented in* `effective.py`.

## 2. Measure over-privilege against observed usage

Effective authority is what an identity *can* do. **Observed authority** is what
it *did*, distilled from audit logs (CloudTrail, Azure Activity, Entra
sign-in/audit) over an observation window into per-footprint facts: count,
first/last seen, and denial count.

**Over-privilege = effective − observed.** The trap is treating "not observed"
as "not needed". A seven-day window never sees a quarterly job. So each unused
effective permission is scored with a **revocation confidence** in `[0, 1]` that
rises with:

- **window length** — silence over 90 days is far stronger evidence than over 3;
- **log coverage** — missing logs cap confidence; a gap in delivery must never
  read as "the identity did nothing";
- **narrowness** — a specific permission is easier to judge than a wildcard that
  may hide a single rare call.

Each permission gets a verdict: **USED**, **UNUSED** (high confidence), or
**UNCERTAIN** (unused but under the confidence floor). Denied attempts are kept
as an *under-privilege* signal — authority the identity is actively reaching
for, which remediation must not blindly strip.

*Implemented in* `observed.py` *and* `overprivilege.py`.

## 3. Plan safe, dependency-aware revocation

The planner never emits a raw delete. It converts findings into a staged,
reversible plan and refuses to touch anything a guard flags. Because the cost of
a false "safe" is an outage, the default posture is **keep unless clearly
safe.**

### Guards (any one blocks or downgrades a revocation)

| Guard | Effect |
|---|---|
| Confidence floor | Below it → only ever *watched*, never revoked. |
| Recent use | Used anywhere in the window → never a candidate. |
| Declared dependency | Operator-tagged / explicitly protected grant is pinned. |
| Break-glass / critical action | `delete`, `decrypt`, `assume-role`, `billing`, `iam:*` … held at the safest stage even when unused — rare *by design*, catastrophic if wrongly removed. |
| Enablement edge | A grant that lets the identity assume another role carries higher blast radius and is staged more cautiously. |

### Stages (each permission lands in exactly one)

1. **MONITOR** — keep; log future use; revisit next cycle.
2. **ALERT** — keep; tell the owner it looks unused (human in the loop).
3. **SHADOW_DENY** — simulate denial in report-only mode so a real dependency
   surfaces as a *blocked-but-logged* event **before** anything breaks.
4. **REVOKE** — detach, with a ready-made rollback and a cool-down window.

Nothing jumps straight to REVOKE. A permission reaches it only when it is
unused with high confidence, narrow, non-critical, **and** has completed a clean
shadow-deny soak (default 14 days with no blocked dependency). The plan is built
to run on a cycle: each pass moves survivors one stage closer to removal, and
every action ships with the exact grant sources to detach and the exact
re-attach to roll back.

*Implemented in* `revocation.py`.

---

## Why shadow-deny is the core safety primitive

The dependency you cannot see in the logs is the one that will cause the
outage. Shadow-deny converts an irreversible guess ("I think nothing uses
this") into a reversible experiment: deny the permission *in audit only*, keep
serving the call, and watch for a would-have-been-blocked event. If one
appears, the permission is promoted back to USED and never revoked. Only
silence through the full soak earns removal. This is what lets the method claim
"without disrupting dependent systems" rather than merely hoping.

## Assumptions and limits

- **Log fidelity bounds everything.** The method's confidence can never exceed
  the completeness of the audit trail; `log_coverage` makes that explicit
  rather than hiding it.
- **Data-plane gaps.** Some providers log control-plane actions far better than
  data-plane ones. Treat data-plane permissions as lower-confidence unless
  data events are enabled.
- **Conditions are coarse-modelled.** A conditional grant is flagged, not fully
  evaluated; the planner is deliberately conservative about conditional denies.
- **The method advises; it does not auto-apply.** REVOKE outputs are change
  proposals (PR / ticket text), kept in a human- and audit-friendly form by
  design.

## Pipeline at a glance

```
grants ──▶ resolve_effective_authority ──▶ EffectiveAuthority (+provenance)
logs   ──▶ summarise_usage            ──▶ ObservedAuthority (+coverage)
                     │
                     ▼
          score_identity ──▶ findings (USED / UNUSED / UNCERTAIN, confidence)
                     │
                     ▼
          plan_revocation ──▶ staged plan (MONITOR → ALERT → SHADOW_DENY → REVOKE)
                               each action: sources to detach · blast radius · rollback
```
