# agent-authority

**Compute the effective authority of non-human and AI-agent identities in cloud
environments, and plan safe, dependency-aware revocation of excess privilege.**

Service principals, managed identities, workload roles, and autonomous AI
agents now vastly outnumber human identities in cloud estates, and they are
routinely over-provisioned — coarse wildcard grants are easy, and nobody is
sure what breaks if a permission is removed. This library answers two questions
precisely:

1. **What can this identity actually do right now?** — the deny-aware,
   boundary-capped *effective authority*, with full provenance.
2. **What can be safely taken away?** — a staged, reversible revocation plan
   that holds critical and protected grants back and soaks everything through a
   shadow-deny phase before any real removal, so dependent systems don't break.

The full approach is written up in **[docs/METHOD.md](docs/METHOD.md)**.

## Why this is different from a permissions linter

Most "unused permissions" tools stop at a set difference and hand you a list to
delete. The hard part — and the reason over-privilege persists — is that
*deleting the wrong unused permission causes an outage*: the quarterly job, the
failover path, the break-glass role are all unused by design. This library
treats removal as a **reversible experiment**, not a guess:

- **Confidence, not booleans.** "Not seen in logs" is scored against window
  length, log coverage, and grant breadth — a 3-day window never claims a
  quarterly permission is dead.
- **Shadow-deny before revoke.** A permission is denied *in audit-only mode*
  first; a real dependency surfaces as a blocked-but-logged event and promotes
  the permission back to "keep" before anything is actually removed.
- **Guards that refuse to touch the dangerous stuff** — critical actions
  (delete, decrypt, assume-role, IAM, billing), operator-protected grants, and
  grants that enable further access are staged most cautiously.
- **Executable output.** Every proposed action names the exact grant sources to
  detach and the exact re-attach to roll back.

## Install

```bash
pip install -e .          # editable install
pip install -e ".[dev]"   # with pytest
```

Zero runtime dependencies — no cloud SDKs required. Adapters parse the JSON you
already export from your provider.

## Quick start

```bash
# Run the worked example: an over-provisioned AI summariser agent
python examples/demo.py

# Or via the CLI against JSON fixtures
agent-authority analyze \
  --identity examples/data/identity.json \
  --events   examples/data/events.json \
  --window-days 90 --json
```

### As a library

```python
from agent_authority import (
    resolve_effective_authority, summarise_usage, score_identity,
    build_report, plan_revocation, render_plan, PlannerConfig,
)

authority = resolve_effective_authority(identity)              # 1. what it can do
obs       = summarise_usage(identity.id, events, start, end)   # 2. what it did
findings  = score_identity(authority, obs)                     # 3. the gap + confidence
plan      = plan_revocation(identity, findings, PlannerConfig())
print(render_plan(plan))                                       # 4. staged, reversible plan
```

## How it works

```
grants ─▶ resolve_effective_authority ─▶ EffectiveAuthority (deny-aware, +provenance)
logs   ─▶ summarise_usage             ─▶ ObservedAuthority (+log coverage)
                      │
            score_identity ─▶ findings: USED / UNUSED / UNCERTAIN  (+confidence 0..1)
                      │
          plan_revocation ─▶  MONITOR → ALERT → SHADOW_DENY → REVOKE
                              each action: grant sources to detach · blast radius · rollback
```

The planner runs on a **cycle**: each pass moves survivors one stage closer to
removal, and nothing reaches `REVOKE` without a clean shadow-deny soak.

## Project layout

```
src/agent_authority/
  model.py          core provider-neutral types (Identity, Grant, Permission…)
  effective.py      deny-override + boundary-capped authority resolution
  observed.py       usage summary from audit logs, with coverage
  overprivilege.py  confidence-scored USED / UNUSED / UNCERTAIN findings
  revocation.py     staged, guarded, reversible revocation planner
  adapters/         AWS IAM / CloudTrail and Azure RBAC / Entra (SDK-free)
  cli.py            `agent-authority analyze`
docs/METHOD.md      the method, in full
examples/           runnable demo + JSON fixtures
tests/              pytest suite (19 tests)
```

## Scope and honesty about limits

- The method **advises**; `REVOKE` outputs are change proposals (PR / ticket
  text), never auto-applied.
- Confidence can never exceed audit-log completeness — `log_coverage` makes that
  explicit rather than hiding it.
- Conditional grants are flagged, not fully evaluated; the planner is
  deliberately conservative about conditional denies.
- Wildcards are compared by glob rather than expanded into a provider's full
  action catalogue, keeping the core cloud-agnostic.

See [docs/METHOD.md](docs/METHOD.md) for the assumptions in detail.

## Tests

```bash
pytest -q
```

## License

Apache-2.0 — see [LICENSE](LICENSE).
