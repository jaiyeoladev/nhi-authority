"""Command-line entry point.

Usage::

    agent-authority analyze --identity identity.json --events events.json \
        [--window-days 90] [--coverage 1.0] [--soaked policy:Foo] [--json]

``identity.json`` is a core-model identity (see examples/data) and
``events.json`` a list of AccessEvent dicts. The command resolves effective
authority, scores over-privilege, and prints a staged revocation plan. This is
a thin wrapper over the library — the real work lives in the modules.
"""

from __future__ import annotations

import argparse
import json
import sys
import time

from .model import AccessEvent, BindingKind, Effect, Grant, Identity, IdentityType, Permission, Policy
from .effective import resolve_effective_authority, authority_breadth
from .observed import summarise_usage
from .overprivilege import score_identity, build_report
from .revocation import PlannerConfig, plan_revocation, render_plan


def _load_identity(d: dict) -> Identity:
    grants = []
    for g in d.get("grants", []):
        perms = [
            Permission(
                action=p["action"],
                resource=p.get("resource", "*"),
                effect=Effect(p.get("effect", "Allow")),
                condition=p.get("condition"),
            )
            for p in g["policy"]["permissions"]
        ]
        boundary = None
        if g.get("boundary"):
            boundary = Policy(
                name=g["boundary"]["name"],
                permissions=[
                    Permission(
                        action=p["action"],
                        resource=p.get("resource", "*"),
                        effect=Effect(p.get("effect", "Allow")),
                        condition=p.get("condition"),
                    )
                    for p in g["boundary"]["permissions"]
                ],
            )
        grants.append(
            Grant(
                policy=Policy(name=g["policy"]["name"], permissions=perms),
                binding=BindingKind(g.get("binding", "direct")),
                source=g.get("source", "direct"),
                boundary=boundary,
                enables=g.get("enables", []),
            )
        )
    return Identity(
        id=d["id"],
        name=d["name"],
        type=IdentityType(d.get("type", "workload")),
        grants=grants,
        tags=d.get("tags", {}),
    )


def _load_events(rows: list[dict]) -> list[AccessEvent]:
    return [
        AccessEvent(
            identity_id=r["identity_id"],
            action=r["action"],
            resource=r.get("resource", "*"),
            timestamp=float(r["timestamp"]),
            outcome=r.get("outcome", "success"),
        )
        for r in rows
    ]


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="agent-authority")
    sub = parser.add_subparsers(dest="cmd", required=True)
    an = sub.add_parser("analyze", help="score over-privilege and plan revocation")
    an.add_argument("--identity", required=True)
    an.add_argument("--events", required=True)
    an.add_argument("--window-days", type=float, default=90.0)
    an.add_argument("--coverage", type=float, default=1.0)
    an.add_argument("--soaked", action="append", default=[],
                    help="grant source that has passed shadow-deny soak (repeatable)")
    an.add_argument("--json", action="store_true", help="emit JSON instead of text")

    args = parser.parse_args(argv)

    with open(args.identity) as fh:
        identity = _load_identity(json.load(fh))
    with open(args.events) as fh:
        events = _load_events(json.load(fh))

    now = time.time()
    window_start = now - args.window_days * 86400
    authority = resolve_effective_authority(identity)
    obs = summarise_usage(identity.id, events, window_start, now, log_coverage=args.coverage)
    findings = score_identity(authority, obs)
    report = build_report(findings, identity.id)
    plan = plan_revocation(
        identity, findings,
        PlannerConfig(soaked_sources=frozenset(args.soaked)),
    )

    if args.json:
        out = {
            "identity": identity.id,
            "effective_permissions": len(authority.permissions),
            "authority_breadth": authority_breadth(authority),
            "over_privilege_ratio": round(report.over_privilege_ratio, 3),
            "counts": {"used": report.used, "unused": report.unused, "uncertain": report.uncertain},
            "plan": plan.summary(),
            "actions": [
                {
                    "action": a.action, "resource": a.resource, "stage": a.stage.value,
                    "sources": a.sources, "reason": a.reason, "blast_radius": a.blast_radius,
                }
                for a in plan.actions
            ],
        }
        print(json.dumps(out, indent=2))
    else:
        print(f"Identity: {identity.name} ({identity.id})")
        print(f"Effective permissions: {len(authority.permissions)}  "
              f"breadth={authority_breadth(authority)}")
        print(f"Over-privilege ratio: {report.over_privilege_ratio:.0%}  "
              f"(used={report.used} unused={report.unused} uncertain={report.uncertain})")
        print()
        print(render_plan(plan))
    return 0


if __name__ == "__main__":
    sys.exit(main())
