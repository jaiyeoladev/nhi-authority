"""Derive *observed* authority — what an identity actually exercised.

Effective authority says what an identity *can* do. Observed authority says
what it *did*, distilled from audit logs over an observation window. The gap
between them is the over-privilege we want to remove.

The subtlety is confidence. "Not observed" is not the same as "not needed":

* A 7-day window sees none of a quarterly batch job's permissions.
* A permission used once on day 1 of a 90-day window is clearly live.
* Denied attempts tell us an identity *wanted* a permission it lacked — the
  opposite signal, useful for catching under-privilege too.

So we summarise usage per footprint with last-seen, count, and the fraction
of the window actually covered by logs, and we expose a coverage figure the
scorer turns into a confidence that a never-seen permission is truly unused.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Iterable

from .model import AccessEvent


@dataclass
class UsageFact:
    """How a single (action, resource) footprint was used in the window."""

    action: str
    resource: str
    count: int = 0
    first_seen: float | None = None
    last_seen: float | None = None
    denials: int = 0


@dataclass
class ObservedAuthority:
    identity_id: str
    window_start: float
    window_end: float
    # Fraction of the window for which logs are actually present (0..1).
    # A gap in log delivery must not be read as "the identity did nothing".
    log_coverage: float = 1.0
    facts: dict[tuple[str, str], UsageFact] = field(default_factory=dict)

    @property
    def window_days(self) -> float:
        return max(0.0, (self.window_end - self.window_start) / 86400.0)

    def used(self, action: str, resource: str) -> bool:
        fact = self.facts.get((action, resource))
        return bool(fact and fact.count > 0)

    def last_seen(self, action: str, resource: str) -> float | None:
        fact = self.facts.get((action, resource))
        return fact.last_seen if fact else None


def summarise_usage(
    identity_id: str,
    events: Iterable[AccessEvent],
    window_start: float,
    window_end: float,
    log_coverage: float = 1.0,
) -> ObservedAuthority:
    """Fold raw access events into a per-footprint usage summary."""
    obs = ObservedAuthority(
        identity_id=identity_id,
        window_start=window_start,
        window_end=window_end,
        log_coverage=max(0.0, min(1.0, log_coverage)),
    )
    for ev in events:
        if ev.identity_id != identity_id:
            continue
        if not (window_start <= ev.timestamp <= window_end):
            continue
        fkey = (ev.action, ev.resource)
        fact = obs.facts.get(fkey)
        if fact is None:
            fact = UsageFact(action=ev.action, resource=ev.resource)
            obs.facts[fkey] = fact
        if ev.outcome == "denied":
            fact.denials += 1
            continue
        fact.count += 1
        if fact.first_seen is None or ev.timestamp < fact.first_seen:
            fact.first_seen = ev.timestamp
        if fact.last_seen is None or ev.timestamp > fact.last_seen:
            fact.last_seen = ev.timestamp
    return obs


def unmet_demand(obs: ObservedAuthority) -> list[UsageFact]:
    """Footprints the identity tried to use but was denied (under-privilege).

    Surfaced so remediation doesn't blindly strip authority an identity is
    actively reaching for — those are candidates to *keep* or formalise, not
    revoke.
    """
    return [f for f in obs.facts.values() if f.denials > 0 and f.count == 0]
