"""agent-authority: effective-authority computation and safe least-privilege
remediation for non-human and AI agent identities in cloud environments."""

from .model import (
    AccessEvent,
    BindingKind,
    EffectiveAuthority,
    EffectivePermission,
    Effect,
    Grant,
    Identity,
    IdentityType,
    Permission,
    Policy,
)
from .effective import authority_breadth, resolve_effective_authority
from .observed import ObservedAuthority, summarise_usage, unmet_demand
from .overprivilege import (
    OverPrivilegeFinding,
    OverPrivilegeReport,
    Verdict,
    build_report,
    score_identity,
)
from .revocation import (
    PlannerConfig,
    RevocationPlan,
    Stage,
    plan_revocation,
    render_plan,
)

__version__ = "0.1.0"

__all__ = [
    "AccessEvent", "BindingKind", "EffectiveAuthority", "EffectivePermission",
    "Effect", "Grant", "Identity", "IdentityType", "Permission", "Policy",
    "authority_breadth", "resolve_effective_authority",
    "ObservedAuthority", "summarise_usage", "unmet_demand",
    "OverPrivilegeFinding", "OverPrivilegeReport", "Verdict", "build_report",
    "score_identity",
    "PlannerConfig", "RevocationPlan", "Stage", "plan_revocation", "render_plan",
]
