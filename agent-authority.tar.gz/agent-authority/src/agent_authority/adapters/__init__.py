"""Provider adapters: translate native IAM/RBAC and logs into the core model.

Each adapter is intentionally thin and dependency-free so the library needs no
cloud SDKs to run. In a real deployment you feed these functions the JSON you
already pull from the provider (policy documents, role assignments, audit log
pages); here they parse plain dicts, which keeps the whole pipeline testable
with synthetic fixtures and no credentials.
"""

from .aws import aws_events, aws_identity_from_iam
from .azure import azure_events, azure_identity_from_rbac

__all__ = [
    "aws_events", "aws_identity_from_iam",
    "azure_events", "azure_identity_from_rbac",
]
