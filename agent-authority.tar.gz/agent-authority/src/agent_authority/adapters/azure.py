"""Azure RBAC / Entra adapter (SDK-free, operates on plain dicts).

Maps role assignments on a service principal or managed identity to the core
model. Azure RBAC role definitions carry ``actions`` / ``notActions`` /
``dataActions`` and a scope; we fold those into permissions whose ``resource``
is the assignment scope, and we honour ``notActions`` as explicit denies.
"""

from __future__ import annotations

from typing import Any, Iterable

from ..model import (
    AccessEvent,
    BindingKind,
    Effect,
    Grant,
    Identity,
    IdentityType,
    Permission,
    Policy,
)


def _as_list(v: Any) -> list[str]:
    if v is None:
        return []
    return v if isinstance(v, list) else [v]


def _role_def_to_permissions(role_def: dict, scope: str) -> list[Permission]:
    perms: list[Permission] = []
    for perm_block in role_def.get("permissions", [{}]):
        for action in _as_list(perm_block.get("actions")):
            perms.append(Permission(action=action, resource=scope, effect=Effect.ALLOW))
        for action in _as_list(perm_block.get("dataActions")):
            perms.append(Permission(action=action, resource=scope, effect=Effect.ALLOW))
        for action in _as_list(perm_block.get("notActions")):
            perms.append(Permission(action=action, resource=scope, effect=Effect.DENY))
    return perms


def azure_identity_from_rbac(principal: dict) -> Identity:
    """Build an Identity from an Entra principal + its role assignments.

    Expected shape::

        {
          "objectId": "...", "displayName": "billing-agent",
          "principalType": "ServicePrincipal",  # or ManagedIdentity
          "tags": {"env": "prod"},
          "assignments": [
             {"roleName": "Contributor", "scope": "/subscriptions/x/rg/billing",
              "roleDefinition": {"permissions": [{"actions": ["*"],
                                 "notActions": ["Microsoft.Authorization/*/Delete"]}]},
              "enables": []},
          ],
        }
    """
    ptype = {
        "ServicePrincipal": IdentityType.SERVICE_PRINCIPAL,
        "ManagedIdentity": IdentityType.MANAGED_IDENTITY,
    }.get(principal.get("principalType", ""), IdentityType.WORKLOAD)

    grants: list[Grant] = []
    for a in principal.get("assignments", []):
        scope = a.get("scope", "*")
        policy = Policy(
            name=f"{a['roleName']}@{scope}",
            permissions=_role_def_to_permissions(a.get("roleDefinition", {}), scope),
        )
        grants.append(
            Grant(
                policy=policy,
                binding=BindingKind.ROLE,
                source=f"assignment:{a['roleName']}@{scope}",
                enables=list(a.get("enables", [])),
            )
        )

    return Identity(
        id=principal.get("objectId", principal["displayName"]),
        name=principal["displayName"],
        type=ptype,
        grants=grants,
        tags={k: str(v) for k, v in principal.get("tags", {}).items()},
    )


def azure_events(identity_id: str, records: Iterable[dict]) -> list[AccessEvent]:
    """Map Azure Activity / Entra audit rows to AccessEvents.

    Each record carries ``operationName`` (e.g. a provider operation string),
    ``resourceId``, ``eventTimestamp`` (epoch seconds), and a ``status``.
    """
    out: list[AccessEvent] = []
    for rec in records:
        status = (rec.get("status") or "").lower()
        outcome = "denied" if status in {"denied", "forbidden", "failed"} else "success"
        out.append(
            AccessEvent(
                identity_id=identity_id,
                action=rec.get("operationName", ""),
                resource=rec.get("resourceId", "*"),
                timestamp=float(rec.get("eventTimestamp", 0.0)),
                outcome=outcome,
            )
        )
    return out
