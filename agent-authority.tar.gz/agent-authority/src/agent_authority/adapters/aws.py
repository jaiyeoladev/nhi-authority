"""AWS IAM / CloudTrail adapter (SDK-free, operates on plain dicts).

``aws_identity_from_iam`` accepts a role description shaped like the output of
``get_role`` + ``list_attached_role_policies`` + each policy's document, and
produces a core :class:`Identity`. ``aws_events`` maps CloudTrail records to
:class:`AccessEvent` objects.

The parsing is deliberately forgiving: it accepts single strings or lists for
``Action``/``Resource`` (as real policy documents do) and records each managed
or inline policy as its own grant source so provenance survives.
"""

from __future__ import annotations

from typing import Any, Iterable

from ..model import (
    AccessEvent,
    BindingKind,
    Effect,
    Grant,
    Identity,
    IdentityType,
    Permission,
    Policy,
)


def _as_list(v: Any) -> list[str]:
    if v is None:
        return []
    return v if isinstance(v, list) else [v]


def _statements_to_permissions(doc: dict) -> list[Permission]:
    perms: list[Permission] = []
    for stmt in _as_list(doc.get("Statement")):
        effect = Effect.DENY if stmt.get("Effect") == "Deny" else Effect.ALLOW
        has_condition = "Condition" in stmt and bool(stmt["Condition"])
        cond = "aws:condition" if has_condition else None
        actions = _as_list(stmt.get("Action")) or _as_list(stmt.get("NotAction"))
        resources = _as_list(stmt.get("Resource")) or ["*"]
        for action in actions:
            for resource in resources:
                perms.append(
                    Permission(
                        action=action,
                        resource=resource,
                        effect=effect,
                        condition=cond,
                    )
                )
    return perms


def aws_identity_from_iam(role: dict) -> Identity:
    """Build an Identity from an AWS role bundle.

    Expected shape::

        {
          "RoleName": "acme-deployer",
          "RoleId": "AROA...",
          "Tags": {"env": "prod"},
          "AttachedPolicies": [
             {"PolicyName": "Deploy", "PolicyDocument": {...},
              "Enables": ["role:acme-release"]},
          ],
          "PermissionsBoundary": {"PolicyDocument": {...}},  # optional
        }
    """
    boundary_doc = (role.get("PermissionsBoundary") or {}).get("PolicyDocument")
    boundary = (
        Policy(name="permissions-boundary", permissions=_statements_to_permissions(boundary_doc))
        if boundary_doc
        else None
    )

    grants: list[Grant] = []
    for attached in role.get("AttachedPolicies", []):
        policy = Policy(
            name=attached["PolicyName"],
            permissions=_statements_to_permissions(attached.get("PolicyDocument", {})),
        )
        grants.append(
            Grant(
                policy=policy,
                binding=BindingKind.DIRECT,
                source=f"policy:{attached['PolicyName']}",
                boundary=boundary,
                enables=list(attached.get("Enables", [])),
            )
        )

    return Identity(
        id=role.get("RoleId", role["RoleName"]),
        name=role["RoleName"],
        type=IdentityType.IAM_ROLE,
        grants=grants,
        tags={k: str(v) for k, v in role.get("Tags", {}).items()},
    )


def aws_events(identity_id: str, records: Iterable[dict]) -> list[AccessEvent]:
    """Map CloudTrail records to AccessEvents.

    Each record is expected to carry ``eventName``, ``eventSource``,
    ``eventTime`` (epoch seconds here for simplicity), an optional
    ``errorCode``, and a resource ARN under ``resourceARN``.
    """
    out: list[AccessEvent] = []
    for rec in records:
        source = rec.get("eventSource", "").split(".")[0]  # "s3.amazonaws.com" -> "s3"
        name = rec.get("eventName", "")
        action = f"{source}:{name}" if source else name
        outcome = "denied" if rec.get("errorCode") in {"AccessDenied", "UnauthorizedOperation"} else "success"
        out.append(
            AccessEvent(
                identity_id=identity_id,
                action=action,
                resource=rec.get("resourceARN", "*"),
                timestamp=float(rec.get("eventTime", 0.0)),
                outcome=outcome,
            )
        )
    return out
