"""Plan *safe* revocation of excess authority.

Finding over-privilege is the easy half. The hard requirement in the thesis
is "without disrupting dependent systems". A naive tool that strips every
unused permission will eventually break the quarterly job, the failover path,
or the break-glass role — precisely the permissions that are rare by design.

This planner never emits a raw "delete". It turns findings into a staged,
reversible plan and refuses to touch anything a dependency guard flags. The
guards are deliberately conservative — the cost of a false "safe" is an
outage, so the default posture is *keep unless clearly safe*.

Guards (any one blocks or downgrades a revocation)
--------------------------------------------------
1. **Confidence floor.** Below it, a permission is only ever *watched*, never
   revoked, regardless of how long it has sat unused.
2. **Recent use.** Used anywhere in the window → never a candidate.
3. **Declared dependencies.** An identity tag or an explicit dependency edge
   ("this permission backs failover") pins a permission as protected.
4. **Break-glass / critical actions.** Actions matching a critical-action
   pattern (delete, decrypt, assume-role, billing) are held at the safest
   stage even when unused, because their blast radius if wrongly removed is
   catastrophic and they are legitimately rare.
5. **Enablement edges.** If a grant lets the identity assume another role,
   revoking it is treated as higher blast radius and staged accordingly.

Stages (each permission lands in exactly one)
---------------------------------------------
* ``MONITOR``  – keep; log every future use; revisit next cycle.
* ``ALERT``    – keep; alert the owner that it looks unused (human in loop).
* ``SHADOW_DENY`` – simulate denial (deny in audit/report-only mode) so a real
  dependency surfaces as a *blocked-but-logged* event before anything breaks.
* ``REVOKE``   – detach, with a ready-made rollback and a cool-down window.

Nothing jumps straight to REVOKE unless it is unused with high confidence,
narrow, non-critical, and has passed (or been explicitly exempted from) a
shadow-deny soak. The plan is designed to be run repeatedly: each cycle moves
survivors one stage closer to removal.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum

from .model import Grant, Identity
from .overprivilege import OverPrivilegeFinding, Verdict
from .model import _glob


class Stage(str, Enum):
    MONITOR = "monitor"
    ALERT = "alert"
    SHADOW_DENY = "shadow_deny"
    REVOKE = "revoke"


# Default critical-action patterns. Matched case-insensitively against the
# action string. Operators should extend this for their estate.
DEFAULT_CRITICAL_ACTIONS = [
    "*delete*", "*deletion*", "*terminate*", "*decrypt*", "*:assumerole",
    "sts:*", "*billing*", "*purge*", "*destroy*", "*remove*", "iam:*",
    "*keyvault*", "*schedulekey*", "*rolemanagement*",
    "microsoft.authorization/*",
]

# Minimum usage-confidence before a permission may ever be proposed for actual
# removal rather than merely watched.
DEFAULT_CONFIDENCE_FLOOR = 0.6
# Days a SHADOW_DENY must soak with no blocked dependency before REVOKE.
DEFAULT_SHADOW_SOAK_DAYS = 14


@dataclass
class RevocationAction:
    action: str
    resource: str
    condition: str | None
    stage: Stage
    # Exact grant sources that must be trimmed to remove this permission.
    sources: list[str]
    reason: str
    blast_radius: str
    rollback: str
    protected_by: list[str] = field(default_factory=list)


@dataclass
class RevocationPlan:
    identity_id: str
    generated_at: float
    actions: list[RevocationAction] = field(default_factory=list)

    def by_stage(self, stage: Stage) -> list[RevocationAction]:
        return [a for a in self.actions if a.stage is stage]

    def summary(self) -> dict[str, int]:
        return {s.value: len(self.by_stage(s)) for s in Stage}


@dataclass
class PlannerConfig:
    critical_actions: list[str] = field(default_factory=lambda: list(DEFAULT_CRITICAL_ACTIONS))
    confidence_floor: float = DEFAULT_CONFIDENCE_FLOOR
    shadow_soak_days: int = DEFAULT_SHADOW_SOAK_DAYS
    # If True, permissions that passed a prior shadow-deny soak (recorded in
    # ``soaked_sources``) may advance to REVOKE this cycle.
    soaked_sources: frozenset[str] = frozenset()


def _is_critical(action: str, patterns: list[str]) -> bool:
    return any(_glob(p, action) for p in patterns)


def _declared_protected(identity: Identity, action: str, resource: str) -> list[str]:
    """Return human-readable reasons this footprint is pinned as protected.

    Two mechanisms:
    * A grant whose source is listed in the identity's ``protect`` tag
      (comma-separated) — operator-declared "do not touch".
    * A grant marked break-glass via tag ``break_glass=<source>`` .
    """
    reasons: list[str] = []
    protect = identity.tags.get("protect", "")
    protected_sources = {s.strip() for s in protect.split(",") if s.strip()}
    for grant in identity.grants:
        if grant.source in protected_sources:
            for p in grant.policy.permissions:
                if _glob(p.action, action) and _glob(p.resource, resource):
                    reasons.append(f"operator-protected grant {grant.source}")
    bg = identity.tags.get("break_glass", "")
    if bg:
        reasons.append(f"identity flagged break-glass ({bg})")
    return reasons


def _enables_other_access(identity: Identity, sources: list[str]) -> list[str]:
    """Which of these grant sources let the identity reach further access."""
    enabling = []
    for grant in identity.grants:
        if grant.source in sources and grant.enables:
            enabling.append(f"{grant.source} enables {', '.join(grant.enables)}")
    return enabling


def plan_revocation(
    identity: Identity,
    findings: list[OverPrivilegeFinding],
    config: PlannerConfig | None = None,
) -> RevocationPlan:
    """Turn over-privilege findings into a staged, safe, reversible plan."""
    cfg = config or PlannerConfig()
    plan = RevocationPlan(identity_id=identity.id, generated_at=time.time())

    for f in findings:
        perm = f.permission
        sources = sorted(perm.sources)

        # USED → never touch.
        if f.verdict is Verdict.USED:
            continue

        protected = _declared_protected(identity, perm.action, perm.resource)
        enabling = _enables_other_access(identity, sources)
        critical = _is_critical(perm.action, cfg.critical_actions)

        # Blast radius narrative, assembled from the signals we have.
        blast_bits = []
        if enabling:
            blast_bits.extend(enabling)
        if critical:
            blast_bits.append("matches a critical-action pattern")
        if "*" in perm.action or "*" in perm.resource:
            blast_bits.append("wildcard footprint — may cover unseen calls")
        blast = "; ".join(blast_bits) if blast_bits else "narrow, isolated permission"

        rollback = (
            "Re-attach " + ", ".join(sources)
            + " (grant sources preserved in plan)."
        )

        # --- staging decision -------------------------------------------
        stage: Stage
        reason: str

        if protected:
            stage = Stage.MONITOR
            reason = "Unused but explicitly protected; keeping and monitoring."
        elif f.verdict is Verdict.UNCERTAIN or f.revocation_confidence < cfg.confidence_floor:
            stage = Stage.ALERT
            reason = (
                "Looks unused but confidence is below the floor "
                f"({f.revocation_confidence:.0%} < {cfg.confidence_floor:.0%}); "
                "alerting owner, not revoking."
            )
        elif critical or enabling:
            # High-confidence-unused but high blast radius → soak first.
            if set(sources).issubset(cfg.soaked_sources):
                stage = Stage.REVOKE
                reason = (
                    "High-confidence unused; passed shadow-deny soak; "
                    "critical/enabling but no dependency surfaced — revoking."
                )
            else:
                stage = Stage.SHADOW_DENY
                reason = (
                    "High-confidence unused but high blast radius; shadow-deny "
                    f"for {cfg.shadow_soak_days}d to surface hidden dependencies "
                    "before removal."
                )
        else:
            # High-confidence-unused, narrow, non-critical.
            if set(sources).issubset(cfg.soaked_sources):
                stage = Stage.REVOKE
                reason = "High-confidence unused, narrow, soaked — safe to revoke."
            else:
                stage = Stage.SHADOW_DENY
                reason = (
                    "High-confidence unused and narrow; shadow-deny soak "
                    f"({cfg.shadow_soak_days}d) confirms no dependency before revoke."
                )

        plan.actions.append(
            RevocationAction(
                action=perm.action,
                resource=perm.resource,
                condition=perm.condition,
                stage=stage,
                sources=sources,
                reason=reason,
                blast_radius=blast,
                rollback=rollback,
                protected_by=protected,
            )
        )

    # Deterministic ordering: safest stages first, then by action.
    stage_order = {Stage.MONITOR: 0, Stage.ALERT: 1, Stage.SHADOW_DENY: 2, Stage.REVOKE: 3}
    plan.actions.sort(key=lambda a: (stage_order[a.stage], a.action, a.resource))
    return plan


def render_plan(plan: RevocationPlan) -> str:
    """Human-readable plan for a PR description or change ticket."""
    lines = [f"# Revocation plan for {plan.identity_id}", ""]
    counts = plan.summary()
    lines.append(
        "Stages: "
        + ", ".join(f"{k}={v}" for k, v in counts.items())
    )
    lines.append("")
    for stage in Stage:
        actions = plan.by_stage(stage)
        if not actions:
            continue
        lines.append(f"## {stage.value.upper()} ({len(actions)})")
        for a in actions:
            cond = f" if {a.condition}" if a.condition else ""
            lines.append(f"- `{a.action}` on `{a.resource}`{cond}")
            lines.append(f"    - why: {a.reason}")
            lines.append(f"    - blast radius: {a.blast_radius}")
            lines.append(f"    - detach: {', '.join(a.sources)}")
            if a.protected_by:
                lines.append(f"    - protected by: {'; '.join(a.protected_by)}")
            lines.append(f"    - rollback: {a.rollback}")
        lines.append("")
    return "\n".join(lines)
