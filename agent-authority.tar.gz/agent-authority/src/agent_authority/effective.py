"""Compute *effective* authority for an identity.

Effective authority is not "the union of every policy attached". A correct
answer has to respect three things every serious cloud IAM engine enforces:

1. **Explicit deny overrides allow.** A single matching Deny beats any number
   of Allows. We model this as: an allow permission survives only if no deny
   in the identity's grants matches the same (action, resource) footprint.
2. **Permission boundaries / SCPs cap grants.** When a grant carries a
   boundary, an allow is effective only where the boundary *also* allows it.
3. **Provenance is preserved.** Over-privilege remediation is useless if you
   can tell someone "trim s3:*" but not *which of five attachments* grants it.
   Every effective permission keeps the set of grant sources that produced it.

The resolver is intentionally conservative about wildcards: it does not try
to expand ``s3:*`` into the full action catalogue (that is provider-specific
and huge). Instead it keeps grants at their stated granularity and relies on
glob matching at comparison time. This keeps the method cloud-agnostic and
avoids inventing actions a provider may not have.
"""

from __future__ import annotations

from collections import defaultdict

from .model import (
    EffectiveAuthority,
    EffectivePermission,
    Effect,
    Grant,
    Identity,
    Permission,
    _glob,
)


def _boundary_allows(boundary_allows: list[Permission], action: str, resource: str) -> bool:
    """True if a boundary (list of its Allow perms) permits the footprint.

    An absent boundary is handled by the caller; here an empty list means the
    boundary allows nothing, which correctly caps everything to deny.
    """
    return any(b.matches(action, resource) for b in boundary_allows)


def _denied(denies: list[tuple[str, Permission]], perm: Permission) -> bool:
    """Is ``perm``'s footprint shadowed by any explicit deny?

    We treat a deny as shadowing an allow when the deny pattern covers the
    allow pattern. Because patterns can be wildcards on both sides, we test
    both directions of glob containment and also an exact action/resource
    overlap, erring toward *recognising* a deny (safer: we never report an
    allow as effective when a deny plausibly removes it).
    """
    for _src, d in denies:
        action_overlap = (
            _glob(d.action, perm.action)
            or _glob(perm.action, d.action)
        )
        resource_overlap = (
            _glob(d.resource, perm.resource)
            or _glob(perm.resource, d.resource)
        )
        if action_overlap and resource_overlap:
            # A conditional deny only shadows an equally/more-conditional
            # allow; an unconditional deny shadows everything it overlaps.
            if d.condition is None or d.condition == perm.condition:
                return True
    return False


def resolve_effective_authority(identity: Identity) -> EffectiveAuthority:
    """Flatten an identity's grants into deny-aware, boundary-capped authority.

    Returns one :class:`EffectivePermission` per distinct effective footprint,
    each carrying the full set of grant sources that produced it.
    """
    # 1. Collect allows and denies with provenance across every grant.
    allows: list[tuple[str, Permission]] = []
    denies: list[tuple[str, Permission]] = []
    # Boundaries are intersected per-grant, so we track the grant each allow
    # came from to apply the right boundary.
    allow_grant: dict[int, Grant] = {}

    for grant in identity.grants:
        for p in grant.policy.permissions:
            if p.effect is Effect.ALLOW:
                allows.append((grant.source, p))
                allow_grant[id(p)] = grant
            else:
                denies.append((grant.source, p))

    # 2. Keep each allow only if it survives deny-override and its grant's
    #    boundary. Merge identical footprints, unioning their sources.
    merged: dict[tuple[str, str, str | None], set[str]] = defaultdict(set)

    for source, perm in allows:
        if _denied(denies, perm):
            continue
        grant = allow_grant[id(perm)]
        if grant.boundary is not None:
            if not _boundary_allows(grant.boundary.allows(), perm.action, perm.resource):
                # Boundary removes this allow entirely.
                continue
        merged[perm.key()].add(source)

    permissions = [
        EffectivePermission(
            action=action,
            resource=resource,
            condition=condition,
            sources=frozenset(sources),
        )
        for (action, resource, condition), sources in sorted(merged.items())
    ]

    return EffectiveAuthority(identity_id=identity.id, permissions=permissions)


def authority_breadth(authority: EffectiveAuthority) -> int:
    """A crude reach metric: how wildcard-heavy the authority is.

    Counts a wildcard in action or resource as broadening reach. Used to rank
    identities by how much latent blast radius they carry even before usage is
    considered — a ``*:*`` service principal scores high regardless of logs.
    """
    score = 0
    for p in authority.permissions:
        if "*" in p.action:
            score += 2
        if p.resource == "*" or p.resource.endswith("/*") or p.resource.endswith(":*"):
            score += 2
        if "*" not in p.action and "*" not in p.resource:
            score += 1
    return score
