"""Cloud-agnostic data model for identities, grants, and authority.

The model is deliberately provider-neutral. Adapters (see ``adapters/``)
translate AWS IAM, Azure RBAC / Entra, GCP IAM, etc. into these types so
that the resolver, scorer, and planner never need to know which cloud a
grant came from.

Key terms
---------
Permission
    A single (action, resource, effect) atom, optionally conditional.
    ``s3:GetObject`` on ``arn:aws:s3:::reports/*`` is one permission.
Grant
    An attachment of a *policy* (a set of permissions) to a principal,
    through some binding (direct, role, group, resource hierarchy).
Identity
    A principal that holds grants. We care about non-human ones:
    service principals, managed identities, service accounts, IAM roles
    assumed by workloads, and AI-agent identities.
EffectiveAuthority
    The flattened, deny-aware set of permissions an identity can actually
    exercise right now. The whole point of this package is to compute it,
    compare it to what the identity *uses*, and shrink the gap safely.
"""

from __future__ import annotations

import fnmatch
from dataclasses import dataclass, field
from enum import Enum
from typing import Iterable


class Effect(str, Enum):
    ALLOW = "Allow"
    DENY = "Deny"


class IdentityType(str, Enum):
    """The non-human identity flavours we reason about."""

    SERVICE_PRINCIPAL = "service_principal"   # Entra app / SP
    MANAGED_IDENTITY = "managed_identity"     # Azure MSI
    SERVICE_ACCOUNT = "service_account"       # GCP / k8s SA
    IAM_ROLE = "iam_role"                     # AWS role assumed by a workload
    AI_AGENT = "ai_agent"                     # autonomous / tool-using agent
    WORKLOAD = "workload"                     # generic machine principal


class BindingKind(str, Enum):
    """How a grant reaches a principal. Governs inheritance semantics."""

    DIRECT = "direct"                 # attached straight to the identity
    GROUP = "group"                   # via group / directory-role membership
    ROLE = "role"                     # via an assumable role / RBAC role
    RESOURCE_HIERARCHY = "hierarchy"  # inherited down a resource scope tree


@dataclass(frozen=True)
class Permission:
    """A single authority atom.

    ``action`` and ``resource`` may contain ``*``/``?`` glob wildcards, which
    is how every major cloud expresses coarse grants (``s3:*``, ``/*``).
    ``condition`` is an opaque, hashable marker describing a constraint that
    narrows when the permission applies (time of day, source IP, tag match).
    Conditional permissions are never treated as freely exercisable: the
    scorer and planner account for the fact that a condition may not hold.
    """

    action: str
    resource: str = "*"
    effect: Effect = Effect.ALLOW
    condition: str | None = None

    def matches(self, action: str, resource: str) -> bool:
        """Does this permission cover a concrete (action, resource) call?"""
        return _glob(self.action, action) and _glob(self.resource, resource)

    def key(self) -> tuple[str, str, str | None]:
        """Identity-independent key used for set arithmetic."""
        return (self.action, self.resource, self.condition)


@dataclass
class Policy:
    """A named bundle of permissions (an IAM policy, an RBAC role def...)."""

    name: str
    permissions: list[Permission] = field(default_factory=list)

    def allows(self) -> list[Permission]:
        return [p for p in self.permissions if p.effect is Effect.ALLOW]

    def denies(self) -> list[Permission]:
        return [p for p in self.permissions if p.effect is Effect.DENY]


@dataclass
class Grant:
    """A policy attached to a principal via some binding.

    ``source`` records human-readable provenance ("group:billing-admins",
    "role:AcmeDeployer") so that a revocation plan can point an operator at
    the exact object to detach. ``boundary`` is an optional permission
    boundary / SCP that caps this grant: an action is only effective if it is
    allowed by the policy *and* permitted by the boundary.
    """

    policy: Policy
    binding: BindingKind = BindingKind.DIRECT
    source: str = "direct"
    boundary: Policy | None = None
    # Grants that only exist because of this one (e.g. a role this grant lets
    # the identity assume). Used for blast-radius reasoning during revocation.
    enables: list[str] = field(default_factory=list)


@dataclass
class Identity:
    """A non-human principal and everything granted to it."""

    id: str
    name: str
    type: IdentityType
    grants: list[Grant] = field(default_factory=list)
    # Free-form labels: environment, owner, criticality, break-glass flags.
    tags: dict[str, str] = field(default_factory=dict)

    def all_boundaries(self) -> list[Policy]:
        return [g.boundary for g in self.grants if g.boundary is not None]


@dataclass(frozen=True)
class EffectivePermission:
    """One resolved, effective permission plus why it is effective."""

    action: str
    resource: str
    condition: str | None
    # Provenance: which grant sources produced this. One effective permission
    # can come from several overlapping grants — all are recorded so the
    # planner knows *everything* that must be trimmed to actually remove it.
    sources: frozenset[str]

    def key(self) -> tuple[str, str, str | None]:
        return (self.action, self.resource, self.condition)


@dataclass
class EffectiveAuthority:
    """The deny-aware, boundary-capped authority of one identity."""

    identity_id: str
    permissions: list[EffectivePermission] = field(default_factory=list)

    def covers(self, action: str, resource: str) -> bool:
        return any(
            _glob(p.action, action) and _glob(p.resource, resource)
            for p in self.permissions
        )

    def keys(self) -> set[tuple[str, str, str | None]]:
        return {p.key() for p in self.permissions}


# --- observed usage -------------------------------------------------------


@dataclass(frozen=True)
class AccessEvent:
    """A single exercised call, distilled from cloud audit logs.

    Adapters map CloudTrail records, Azure Activity log rows, and Entra
    sign-in / audit events onto this shape.
    """

    identity_id: str
    action: str
    resource: str
    timestamp: float  # epoch seconds
    outcome: str = "success"  # "success" | "denied" | "error"


def _glob(pattern: str, value: str) -> bool:
    """Wildcard match that also treats a bare ``*`` as match-all.

    Cloud action/resource strings are case-insensitive in practice, so we
    fold case before matching.
    """
    if pattern == "*" or pattern == value:
        return True
    return fnmatch.fnmatch(value.lower(), pattern.lower())


def flatten_permissions(policies: Iterable[Policy]) -> list[Permission]:
    out: list[Permission] = []
    for pol in policies:
        out.extend(pol.permissions)
    return out
