"""Score over-privilege: effective authority an identity does not use.

For each effective permission we decide whether it was exercised in the
observation window, and with what confidence an unused permission is *safe to
remove*. That confidence rises with:

* **Window length.** 90 days of silence is stronger evidence than 3 days.
* **Log coverage.** Missing logs cap confidence — we never claim certainty we
  don't have.
* **Narrowness.** A specific permission (no wildcards) is easier to judge than
  a coarse ``s3:*``, which may hide an action used once.

The output per permission is an :class:`OverPrivilegeFinding` with a verdict
(USED / UNUSED / UNCERTAIN) and a ``revocation_confidence`` in [0, 1]. The
planner later combines this confidence with dependency signals before it is
willing to actually propose removing anything.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from enum import Enum

from .effective import EffectiveAuthority
from .model import EffectivePermission
from .observed import ObservedAuthority


class Verdict(str, Enum):
    USED = "used"
    UNUSED = "unused"
    UNCERTAIN = "uncertain"


@dataclass
class OverPrivilegeFinding:
    permission: EffectivePermission
    verdict: Verdict
    revocation_confidence: float  # 0..1; how safe removal looks on usage alone
    last_used: float | None
    rationale: str


# Tunables. Exposed as module constants so operators can calibrate to their
# own risk appetite rather than hard-coding a policy into the logic.
FULL_CONFIDENCE_WINDOW_DAYS = 90.0   # window at which silence is fully trusted
MIN_WINDOW_DAYS = 7.0                # below this, "unused" is never confident
WILDCARD_PENALTY = 0.25             # confidence multiplier hit per wildcard


def _window_confidence(obs: ObservedAuthority) -> float:
    """Confidence contributed by how long and how completely we observed."""
    if obs.window_days < MIN_WINDOW_DAYS:
        base = 0.2 * (obs.window_days / MIN_WINDOW_DAYS)
    else:
        # Saturating curve: approaches 1.0 as the window approaches the full
        # trusted length, never quite reaching certainty.
        ratio = min(1.0, obs.window_days / FULL_CONFIDENCE_WINDOW_DAYS)
        base = 1.0 - math.exp(-3.0 * ratio)
    return base * obs.log_coverage


def _breadth_penalty(perm: EffectivePermission) -> float:
    """Multiplier that lowers confidence for wildcard-heavy permissions."""
    wildcards = 0
    if "*" in perm.action:
        wildcards += 1
    if "*" in perm.resource:
        wildcards += 1
    return max(0.2, 1.0 - WILDCARD_PENALTY * wildcards)


def _permission_used(perm: EffectivePermission, obs: ObservedAuthority) -> tuple[bool, float | None]:
    """Did any observed call fall under this effective permission's footprint?

    A wildcard permission is 'used' if *any* concrete call it covers appears
    in the logs. Returns (used, latest_timestamp_of_a_covering_call).
    """
    from .model import _glob

    latest: float | None = None
    used = False
    for (action, resource), fact in obs.facts.items():
        if fact.count == 0:
            continue
        if _glob(perm.action, action) and _glob(perm.resource, resource):
            used = True
            if fact.last_seen is not None and (latest is None or fact.last_seen > latest):
                latest = fact.last_seen
    return used, latest


def score_identity(
    authority: EffectiveAuthority,
    obs: ObservedAuthority,
) -> list[OverPrivilegeFinding]:
    """Produce one finding per effective permission."""
    win_conf = _window_confidence(obs)
    findings: list[OverPrivilegeFinding] = []

    for perm in authority.permissions:
        used, last = _permission_used(perm, obs)
        if used:
            findings.append(
                OverPrivilegeFinding(
                    permission=perm,
                    verdict=Verdict.USED,
                    revocation_confidence=0.0,
                    last_used=last,
                    rationale="Exercised within the observation window.",
                )
            )
            continue

        confidence = win_conf * _breadth_penalty(perm)
        if confidence >= 0.6:
            verdict = Verdict.UNUSED
            rationale = (
                f"No covering call in {obs.window_days:.0f}d "
                f"(coverage {obs.log_coverage:.0%}); safe-to-remove "
                f"confidence {confidence:.0%}."
            )
        else:
            verdict = Verdict.UNCERTAIN
            rationale = (
                f"Unused, but confidence only {confidence:.0%} "
                f"(window {obs.window_days:.0f}d, coverage {obs.log_coverage:.0%}"
                f"{', wildcard grant' if '*' in perm.action + perm.resource else ''})."
            )
        findings.append(
            OverPrivilegeFinding(
                permission=perm,
                verdict=verdict,
                revocation_confidence=round(confidence, 3),
                last_used=None,
                rationale=rationale,
            )
        )

    return findings


@dataclass
class OverPrivilegeReport:
    identity_id: str
    total: int
    used: int
    unused: int
    uncertain: int
    findings: list[OverPrivilegeFinding]

    @property
    def over_privilege_ratio(self) -> float:
        """Fraction of effective authority that went unused (any confidence)."""
        if self.total == 0:
            return 0.0
        return (self.unused + self.uncertain) / self.total


def build_report(findings: list[OverPrivilegeFinding], identity_id: str) -> OverPrivilegeReport:
    used = sum(1 for f in findings if f.verdict is Verdict.USED)
    unused = sum(1 for f in findings if f.verdict is Verdict.UNUSED)
    uncertain = sum(1 for f in findings if f.verdict is Verdict.UNCERTAIN)
    return OverPrivilegeReport(
        identity_id=identity_id,
        total=len(findings),
        used=used,
        unused=unused,
        uncertain=uncertain,
        findings=findings,
    )
