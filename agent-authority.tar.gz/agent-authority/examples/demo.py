"""End-to-end demo on a synthetic over-privileged AI-agent identity.

Run from the repo root::

    python examples/demo.py

It builds a service-principal-style AI agent granted far more than it uses,
feeds in 90 days of synthetic usage, and prints the effective authority, the
over-privilege report, and the staged revocation plan — showing that the
critical/wildcard grants are held back for a shadow-deny soak while narrow
unused ones are advanced, and the one protected grant is never touched.
"""

from __future__ import annotations

import sys
import time
from pathlib import Path

# Make the package importable when run straight from a checkout.
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from agent_authority import (  # noqa: E402
    BindingKind, Effect, Grant, Identity, IdentityType, Permission, Policy,
    AccessEvent, resolve_effective_authority, authority_breadth,
    summarise_usage, score_identity, build_report, Verdict,
    PlannerConfig, plan_revocation, render_plan,
)


def build_agent() -> Identity:
    """A tool-using AI agent that collects reports and posts summaries.

    What it actually needs: read a reports bucket, write to a summaries bucket,
    read a config secret. What it was granted: all of the above *plus* a broad
    storage wildcard, a key-deletion permission, and an assume-role grant it
    has never exercised — the classic over-provisioned agent.
    """
    read_reports = Policy("read-reports", [
        Permission("s3:GetObject", "arn:aws:s3:::acme-reports/*"),
        Permission("s3:ListBucket", "arn:aws:s3:::acme-reports"),
    ])
    write_summaries = Policy("write-summaries", [
        Permission("s3:PutObject", "arn:aws:s3:::acme-summaries/*"),
    ])
    read_secret = Policy("read-config", [
        Permission("secretsmanager:GetSecretValue",
                   "arn:aws:secretsmanager:*:*:secret:agent/config-*"),
    ])
    # Over-broad grants the agent never uses:
    broad_storage = Policy("broad-storage", [
        Permission("s3:*", "arn:aws:s3:::*"),
    ])
    key_admin = Policy("key-admin", [
        Permission("kms:ScheduleKeyDeletion", "*"),
        Permission("kms:Decrypt", "arn:aws:kms:*:*:key/*"),
    ])
    assume_release = Policy("assume-release", [
        Permission("sts:AssumeRole", "arn:aws:iam::*:role/acme-release"),
    ])
    # A protected grant: break-glass path, unused by design.
    break_glass = Policy("break-glass-restore", [
        Permission("s3:PutObject", "arn:aws:s3:::acme-reports-restore/*"),
    ])

    return Identity(
        id="AROA-AGENT-001",
        name="report-summariser-agent",
        type=IdentityType.AI_AGENT,
        grants=[
            Grant(read_reports, BindingKind.DIRECT, "policy:read-reports"),
            Grant(write_summaries, BindingKind.DIRECT, "policy:write-summaries"),
            Grant(read_secret, BindingKind.DIRECT, "policy:read-config"),
            Grant(broad_storage, BindingKind.DIRECT, "policy:broad-storage"),
            Grant(key_admin, BindingKind.DIRECT, "policy:key-admin"),
            Grant(assume_release, BindingKind.ROLE, "policy:assume-release",
                  enables=["role:acme-release"]),
            Grant(break_glass, BindingKind.DIRECT, "policy:break-glass-restore"),
        ],
        tags={"env": "prod", "owner": "data-platform",
              "protect": "policy:break-glass-restore"},
    )


def synthetic_usage(identity_id: str, now: float) -> list[AccessEvent]:
    """90 days of the agent doing only its real job."""
    events: list[AccessEvent] = []
    day = 86400
    for d in range(0, 90, 1):
        t = now - (90 - d) * day
        events.append(AccessEvent(identity_id, "s3:GetObject",
                                  "arn:aws:s3:::acme-reports/2026/report.json", t))
        events.append(AccessEvent(identity_id, "s3:ListBucket",
                                  "arn:aws:s3:::acme-reports", t))
        events.append(AccessEvent(identity_id, "s3:PutObject",
                                  "arn:aws:s3:::acme-summaries/daily.md", t))
    # config secret read weekly
    for w in range(0, 90, 7):
        t = now - (90 - w) * day
        events.append(AccessEvent(identity_id, "secretsmanager:GetSecretValue",
                                  "arn:aws:secretsmanager:eu-west-2:111:secret:agent/config-ab12", t))
    # one denied attempt: the agent *tried* something it lacks (under-priv signal)
    events.append(AccessEvent(identity_id, "sns:Publish",
                              "arn:aws:sns:eu-west-2:111:agent-alerts",
                              now - 3 * day, outcome="denied"))
    return events


def main() -> None:
    now = time.time()
    agent = build_agent()
    events = synthetic_usage(agent.id, now)

    authority = resolve_effective_authority(agent)
    print("=" * 72)
    print(f"EFFECTIVE AUTHORITY — {agent.name}")
    print("=" * 72)
    for p in authority.permissions:
        print(f"  {p.action:<38} {p.resource:<42} [{','.join(sorted(p.sources))}]")
    print(f"\n  breadth score: {authority_breadth(authority)}")

    obs = summarise_usage(agent.id, events, now - 90 * 86400, now, log_coverage=1.0)
    findings = score_identity(authority, obs)
    report = build_report(findings, agent.id)

    print("\n" + "=" * 72)
    print("OVER-PRIVILEGE REPORT")
    print("=" * 72)
    print(f"  over-privilege ratio: {report.over_privilege_ratio:.0%} "
          f"(used={report.used} unused={report.unused} uncertain={report.uncertain})")
    for f in findings:
        mark = {"used": "✓ USED   ", "unused": "✗ UNUSED ", "uncertain": "? UNCERT "}[f.verdict.value]
        print(f"  {mark} {f.permission.action:<36} conf={f.revocation_confidence:.0%}")

    # First cycle: nothing soaked yet.
    plan = plan_revocation(agent, findings, PlannerConfig())
    print("\n" + "=" * 72)
    print("REVOCATION PLAN — cycle 1 (nothing soaked yet)")
    print("=" * 72)
    print(render_plan(plan))

    # Second cycle: the narrow + broad unused grants have soaked successfully.
    soaked = frozenset({"policy:broad-storage", "policy:key-admin",
                        "policy:assume-release"})
    plan2 = plan_revocation(agent, findings, PlannerConfig(soaked_sources=soaked))
    print("=" * 72)
    print("REVOCATION PLAN — cycle 2 (after a clean 14-day shadow-deny soak)")
    print("=" * 72)
    print(render_plan(plan2))


if __name__ == "__main__":
    main()
