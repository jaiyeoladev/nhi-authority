# Security reporting

Do not include real credentials or sensitive policy snapshots in public issues. For a vulnerability, use GitHub private vulnerability reporting if the repository owner enables it, or contact the owner through a verified private channel. No private reporting endpoint is configured by this template.

This application is a loopback-only research tool. Production hosting, authentication and live AWS changes are outside the supported deployment model.
