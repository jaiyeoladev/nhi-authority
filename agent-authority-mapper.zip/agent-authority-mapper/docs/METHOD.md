# Method and evaluation

## Research objective

Develop a reproducible method for describing machine and agent authority and evaluating permission reductions against known workload dependencies. This release implements a deliberately bounded first experiment, not the entire objective.

## Model

Let Q be the finite set of submitted concrete action/resource tuples. Evaluate each tuple against supplied identity statements and an optional permissions boundary. An applicable unconditional explicit deny dominates. Identity allows combine; the boundary must also allow. Potentially applicable unsupported semantics produce unknown, unless an unconditional deny already establishes denial.

Action matching is case insensitive and resource matching is case sensitive. The matcher supports simple wildcard patterns using Python fnmatch, not the complete AWS ARN matching grammar. Do not infer full AWS parity. Policy variables, conditions and inverse selectors are unsupported.

The reported scope is the subset of Q labelled allowed. No completeness claim is made about authority outside Q or omitted policy layers.

## Dependency-aware proposal

Let D be requests declared required or observed. A review candidate is an allowed tuple outside D. Retain all original policies and append one exact deny statement per candidate. This avoids creating new allows and avoids reconstructing policies from sparse evidence. Replay D against the proposal. Block review readiness if a dependency fails, relevant semantics are unknown, dependency evidence is absent, or no candidates exist.

Ready for sandbox review means model checks passed. It never means safe for production deployment. Permissions considered unobserved can be necessary for monthly jobs, failure recovery or unrecorded workloads.

## Evidence artifacts

The JSON export contains the input fingerprint, per-request reasoning, before and after dependency decisions, baseline policies, candidate bundle, blockers, limitations and rollout checklist. The fingerprint identifies input bytes after canonical JSON serialization. It is not a signature or an integrity guarantee against an attacker controlling both input and report.

## Experiment protocol

1. Establish an isolated test account and a representative agent workload.
2. Collect every relevant policy layer and create a versioned evidence snapshot.
3. Expand Q using resource inventory and workload contracts.
4. Declare dependencies using workload-owner evidence and activity with explicit observation windows.
5. Compare supported request decisions to AWS policy tooling and investigate discrepancies.
6. Run positive, negative, periodic and failure-recovery integration tests before and after the proposal.
7. Record authorization agreement, unknown fraction, regression rate and rollback recovery time.

This repository includes deterministic unit tests and a synthetic fixture. It does not include measurements from live AWS experiments, operational success rates or independent research validation.

## Architecture

```mermaid
flowchart TD
    A[Snapshot and request universe] --> B[Validation]
    B --> C[Policy model]
    C --> D[Decision evidence]
    D --> E[Dependency comparison]
    E --> F[Candidate deny bundle]
    F --> G[Dependency replay]
    G --> H[Review report and blockers]
```

## Future research

Add authenticated read-only collection, service-aware authorization semantics, resource and organisation policies, trust graphs, bounded role traversal, temporal usage coverage, live sandbox tests and monitored canary rollback. Each extension needs its own correctness evaluation.
