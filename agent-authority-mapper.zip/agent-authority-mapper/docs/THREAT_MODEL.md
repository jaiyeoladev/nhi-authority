# Threat model

## Assets and trust boundaries

Policy snapshots may expose resource names and workload structure. Treat imports and reports as sensitive. Input files are untrusted; declared usage and requirements are unverified evidence. Browser-to-loopback HTTP and imported JSON are the primary boundaries. There is no AWS credential boundary in this release because no credentials are collected.

## Threats and controls

| Threat | Implemented control | Remaining limitation |
| --- | --- | --- |
| Malicious text rendered as HTML | DOM textContent, no dynamic HTML insertion, restrictive CSP | Browser and operating system remain trusted |
| Oversized input | 1 MB request limit and 500-request limit | Local server has no production denial-of-service protection |
| Cross-origin analysis submission | Origin check and no CORS grants | No authentication, intended for trusted local use |
| False safety claim from incomplete logs | Review-only labels and mandatory dependency replay | Declared evidence can be inaccurate or incomplete |
| Removing unknown dependencies | Exact tuple denies and staged sandbox checklist | Exact tuples can still affect undeclared workloads |
| Stale policy state | Exported snapshot SHA-256 and current-state review instruction | No automatic drift detection |
| Secret exposure in repository | Synthetic data only, no cloud integration | Users must review their own imports before committing |

Rollback is a documented operational procedure, not an implemented cloud controller. Removing the added deny policy restores the supplied baseline only if other policy state has not changed. Never interpret the report as proof of complete authority or disruption-free revocation.
