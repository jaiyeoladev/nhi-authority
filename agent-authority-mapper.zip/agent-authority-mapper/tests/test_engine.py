import copy,json,unittest
from pathlib import Path
from engine import analyse
class EngineTests(unittest.TestCase):
 def setUp(self): self.d=json.loads((Path(__file__).parents[1]/'examples/demo.json').read_text())
 def test_demo(self):
  r=analyse(self.d);self.assertEqual(r['counts'],{'allowed':5,'denied':1,'unknown':0});self.assertEqual(r['candidate_count'],4);self.assertEqual(r['status'],'ready_for_sandbox_review');self.assertTrue(all(c['passed'] for c in r['checks']))
 def test_denies_candidates_and_retains_baseline(self):
  r=analyse(self.d);self.assertEqual(r['candidate_policies'][:-1],self.d['policies']);self.d['policies']=r['candidate_policies'];after=analyse(self.d);self.assertEqual(after['counts']['allowed'],1)
 def test_explicit_deny_precedence(self):
  self.d['requests'][4]['required']=True;self.assertEqual(analyse(self.d)['status'],'blocked')
 def test_condition_unknown(self):
  self.d['policies'][0]['Statement'][0]['Condition']={'StringEquals':{'aws:PrincipalTag/team':'research'}};r=analyse(self.d);self.assertEqual(r['status'],'blocked');self.assertGreater(r['counts']['unknown'],0)
 def test_boundary(self):
  self.d['boundary']={'Statement':{'Effect':'Allow','Action':'s3:GetObject','Resource':'*'}};self.assertEqual(analyse(self.d)['counts']['allowed'],2)
 def test_observed_preserved(self):
  self.d['requests'][1]['observed']=True;r=analyse(self.d);self.assertEqual(r['candidate_count'],3);self.assertEqual(len(r['checks']),2)
 def test_no_dependency_blocked(self):
  for r in self.d['requests']:r['required']=False;r['observed']=False
  self.assertEqual(analyse(self.d)['status'],'blocked')
 def test_bad_input(self):
  for v in ({},[],{'identity':'x','policies':[],'requests':[]}):
   with self.assertRaises(ValueError):analyse(v)
 def test_wildcard_request_rejected(self):
  self.d['requests'][0]['resource']='*'
  with self.assertRaises(ValueError):analyse(self.d)
 def test_notaction_unknown(self):
  self.d['policies']=[{'Statement':{'Effect':'Allow','NotAction':'iam:*','Resource':'*'}}];self.assertEqual(analyse(self.d)['counts']['unknown'],6)
 def test_resource_case_sensitive(self):
  self.d['requests'][0]['resource']='arn:aws:s3:::RESEARCH-documents/report.txt';self.assertEqual(analyse(self.d)['rows'][0]['decision'],'denied')
 def test_variable_unknown(self):
  self.d['policies'][0]['Statement'][0]['Resource']='arn:aws:s3:::${aws:PrincipalTag/bucket}/*'
  self.assertEqual(analyse(self.d)['rows'][0]['decision'],'unknown')
 def test_no_mutation(self):
  baseline=copy.deepcopy(self.d);analyse(self.d);self.assertEqual(baseline,self.d)
if __name__=='__main__':unittest.main()
