# Agent Authority Mapper

A runnable research application for examining the authority of non-human and AI agent identities and preparing dependency-aware permission reduction plans.

**Status:** offline research prototype. Not a complete AWS authorization engine, a production revocation service, or evidence of independently validated novelty.

## Run in two steps

Requires Python 3.11 or later. No dependencies, AWS account, API key or installation needed.

```bash
python app.py
```

Open http://127.0.0.1:8080 and click **Analyse authority**. The demo loads automatically. On Windows, use `py app.py` if `python` is unavailable. To change ports, run `python app.py --port 8081`.

## What you can do

* Load the included demonstration or import a JSON snapshot.
* Evaluate concrete action/resource requests against identity policies and an optional permissions boundary.
* Inspect allowed, denied and unknown decisions, with statement provenance in the report.
* Declare required and observed workload operations to protect them during model replay.
* Generate an additive exact-deny policy bundle, a baseline rollback artifact and staged rollout checklist.
* Export a JSON report with a deterministic snapshot fingerprint.

The app makes no cloud calls and does not modify AWS. Imported snapshots are processed in server memory and are not written to disk. The local server is bound to loopback. Do not expose it directly to the internet.

## Demonstration

The sample agent can read, write and delete objects in research and finance buckets, with an explicit deny on finance writes. Six concrete requests yield five allowed and one denied. Research document retrieval is a declared dependency. Four other requests become review candidates. The generated bundle retains the baseline and adds exact denies for those four operations. The required retrieval passes model replay.

These are six requests for specific objects, not an enumeration of every permission on either bucket. Other objects remain outside the demonstrated reduction.

## Input schema

See [examples/demo.json](examples/demo.json). `identity` is a descriptive label, not an authenticated AWS identity. `policies` is a nonempty array of identity policy documents. `boundary` is an optional single policy document. `requests` is an array of 1 to 500 objects with concrete `action`, `resource`, optional boolean `required` and `observed`, and optional descriptive `workload`. Observed evidence is user supplied, not independently collected or authenticated. No time-window claim is implied.

Unsupported selectors, conditions and principal semantics return unknown where potentially relevant. No resource policies, SCPs, RCPs, session policies, role trust or assumption chains are evaluated. Missing external controls can change real authorization outcomes, including requests labelled allowed or denied in this model.

## API and Python use

`GET /api/demo` returns the fixture. `POST /api/analyse` accepts a snapshot and returns the report. Invalid inputs receive HTTP 400. Request bodies are limited to 1 MB.

```python
import json
from engine import analyse
with open('examples/demo.json') as f:
    report = analyse(json.load(f))
print(report['status'])
```

## Verification

```bash
python -m unittest discover -s tests -v
```

Tests cover deny precedence, boundaries, unsupported semantics, observed dependencies, request validation, preservation and non-mutation. GitHub Actions runs the suite on Python 3.11 through 3.13.

## Upload to GitHub

1. Extract this project ZIP.
2. Create an empty GitHub repository named `agent-authority-mapper`.
3. In its folder run the commands below, replacing YOUR_USERNAME.

```bash
git init
git add .
git commit -m "Initial authority analysis research prototype"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/agent-authority-mapper.git
git push -u origin main
```

Alternatively use GitHub's **uploading an existing file** option. Preserve `.github/workflows/test.yml` for automated checks. GitHub hosts the source; GitHub Pages cannot run this Python backend.

## Research documentation

[Method and evaluation](docs/METHOD.md), [threat model](docs/THREAT_MODEL.md), [responsible reporting](SECURITY.md).

AWS authorization reference: https://docs.aws.amazon.com/IAM/latest/UserGuide/reference_policies_evaluation-logic.html

## License

MIT. Review and select a license appropriate for your intended research and publication strategy before publishing.
