"""Conservative, finite-request AWS identity policy research evaluator."""
import copy
import fnmatch
import hashlib
import json

def seq(x):
    return x if isinstance(x, list) else [x]

def validate(data):
    if not isinstance(data, dict): raise ValueError("Input must be an object")
    if not isinstance(data.get('identity'), str): raise ValueError("identity must be a string")
    policies=data.get('policies')
    if not isinstance(policies,list) or not policies: raise ValueError("policies must be a nonempty list")
    for policy in policies + ([data['boundary']] if data.get('boundary') is not None else []):
        if not isinstance(policy,dict) or 'Statement' not in policy: raise ValueError("Each policy needs Statement")
        for s in seq(policy['Statement']):
            if not isinstance(s,dict) or s.get('Effect') not in ('Allow','Deny'): raise ValueError("Invalid policy statement")
            for field in ('Action','Resource'):
                if field in s and (not seq(s[field]) or not all(isinstance(v,str) and v for v in seq(s[field]))): raise ValueError("Invalid "+field)
    requests=data.get('requests')
    if not isinstance(requests,list) or not requests or len(requests)>500: raise ValueError("Provide 1 to 500 requests")
    for r in requests:
        if not isinstance(r,dict) or not all(isinstance(r.get(k),str) and r[k] for k in ('action','resource')): raise ValueError("Requests need action and resource")
        if any(c in r['action']+r['resource'] for c in '*?${'): raise ValueError("Requests must use concrete actions and resources")
        for k in ('required','observed'):
            if k in r and not isinstance(r[k],bool): raise ValueError(k+" must be boolean")

def match(pattern,value,action=False):
    return fnmatch.fnmatchcase(value.lower() if action else value, pattern.lower() if action else pattern)

def layer(policy,request):
    allow=False
    unknown=False
    reasons=[]
    for i,s in enumerate(seq(policy['Statement'])):
        # Unsupported selectors and conditions never establish an allow or deny.
        unsupported=bool(set(s)-{'Sid','Effect','Action','Resource'}) or 'Action' not in s or 'Resource' not in s
        variable=any('${' in v or '[' in v for k in ('Action','Resource') for v in seq(s.get(k,[])))
        unsupported=unsupported or variable
        if not variable and 'Action' in s and not any(match(a,request['action'],True) for a in seq(s['Action'])): continue
        if not variable and 'Resource' in s and not any(match(a,request['resource']) for a in seq(s['Resource'])): continue
        if unsupported:
            unknown=True
            reasons.append('Unsupported statement '+str(s.get('Sid',i)))
        elif s['Effect']=='Deny': return 'deny',['Explicit deny: '+str(s.get('Sid',i))]
        else:
            allow=True
            reasons.append('Allow: '+str(s.get('Sid',i)))
    return ('unknown' if unknown else 'allow' if allow else 'implicit_deny'),reasons

def evaluate(data,r):
    results=[layer(p,r) for p in data['policies']]
    if any(s=='deny' for s,_ in results): return 'denied',[x for s,rr in results if s=='deny' for x in rr]
    boundary=layer(data['boundary'],r) if data.get('boundary') is not None else ('allow',[])
    if boundary[0] in ('deny','implicit_deny'): return 'denied',['Boundary does not allow request']
    if any(s=='unknown' for s,_ in results) or boundary[0]=='unknown': return 'unknown',['Unsupported policy semantics may affect this request']
    if any(s=='allow' for s,_ in results): return 'allowed',[x for _,rr in results for x in rr]
    return 'denied',['No identity policy allow']

def analyse(data):
    validate(data)
    rows=[]
    for r in data['requests']:
        state,reasons=evaluate(data,r)
        rows.append(dict(r,decision=state,reasons=reasons,review_candidate=state=='allowed' and not r.get('required',False) and not r.get('observed',False)))
    # Retain all original statements, add exact denies for review candidates.
    # Never synthesize new allows or discard unenumerated authority.
    candidate=copy.deepcopy(data['policies'])
    removals=[r for r in rows if r['review_candidate']]
    if removals:
        candidate.append({'Version':'2012-10-17','Statement':[{'Sid':'ReviewReduction'+str(i),'Effect':'Deny','Action':r['action'],'Resource':r['resource']} for i,r in enumerate(removals)]})
    after=copy.deepcopy(data); after['policies']=candidate
    checks=[]
    for r in rows:
        if r.get('required') or r.get('observed'):
            decision,_=evaluate(after,r)
            checks.append({'action':r['action'],'resource':r['resource'],'workload':r.get('workload','Unspecified'),'before':r['decision'],'after':decision,'passed':r['decision']=='allowed' and decision=='allowed'})
    blockers=[]
    if any(r['decision']=='unknown' for r in rows): blockers.append('Resolve unsupported policy semantics.')
    if not checks: blockers.append('Declare required operations or observed dependencies.')
    if any(not c['passed'] for c in checks): blockers.append('Required or observed operation cannot be confirmed as allowed.')
    if not removals: blockers.append('No review candidates in the supplied request universe.')
    return {'identity':data['identity'],'snapshot_sha256':hashlib.sha256(json.dumps(data,sort_keys=True).encode()).hexdigest(),'scope':'Finite supplied requests; identity policies and optional boundary only. No live AWS verification.','rows':rows,'counts':{k:sum(r['decision']==k for r in rows) for k in ('allowed','denied','unknown')},'candidate_count':len(removals),'candidate_policies':candidate,'baseline_policies':data['policies'],'checks':checks,'blockers':blockers,'status':'blocked' if blockers else 'ready_for_sandbox_review','rollout':['Archive baseline and verify snapshot against current policies.','Obtain workload owner review and expand dependency coverage, including periodic jobs.','Validate with AWS policy tooling and run integration tests in an isolated account.','Apply reviewed deny policy to a canary identity during an approved change window.','Monitor access failures and workload health; remove the added deny policy to roll back.'],'limitations':['Unobserved is not proven unnecessary.','No resource policies, SCPs, RCPs, session policies, trust policies or role assumption traversal.','Condition, NotAction, NotResource, Principal, variables and other unsupported semantics return unknown where relevant.','Counts describe request tuples, not all possible cloud authority.','Model replay is not a live workload test and cannot prove disruption-free revocation.']}
