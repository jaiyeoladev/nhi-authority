"""Local dashboard and JSON API. No cloud credentials or third-party packages."""
import argparse
import json
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from engine import analyse
ROOT=Path(__file__).parent
class Handler(BaseHTTPRequestHandler):
    def send(self,status,body,kind='application/json'):
        self.send_response(status)
        self.send_header('Content-Type',kind+'; charset=utf-8')
        self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('Cache-Control','no-store')
        self.send_header('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; object-src 'none'; frame-ancestors 'none'")
        self.end_headers(); self.wfile.write(body)
    def do_GET(self):
        routes={'/':('static/index.html','text/html'),'/app.js':('static/app.js','text/javascript'),'/style.css':('static/style.css','text/css'),'/api/demo':('examples/demo.json','application/json')}
        if self.path not in routes: return self.send(404,b'{"error":"Not found"}')
        name,kind=routes[self.path]; self.send(200,(ROOT/name).read_bytes(),kind)
    def do_POST(self):
        if self.path!='/api/analyse': return self.send(404,b'{"error":"Not found"}')
        origin=self.headers.get('Origin')
        if origin and origin != 'http://'+self.headers.get('Host',''): return self.send(403,b'{"error":"Cross-origin requests refused"}')
        try:
            size=int(self.headers.get('Content-Length','0'))
            if not 0<size<=1000000: raise ValueError('Body must be between 1 byte and 1 MB')
            data=json.loads(self.rfile.read(size))
            result=analyse(data)
            self.send(200,json.dumps(result).encode())
        except (ValueError,TypeError,KeyError,RecursionError) as e: self.send(400,json.dumps({'error':str(e)}).encode())
if __name__=='__main__':
    parser=argparse.ArgumentParser(); parser.add_argument('--port',type=int,default=8080); args=parser.parse_args()
    print(f'Agent Authority Mapper: http://127.0.0.1:{args.port}')
    ThreadingHTTPServer(('127.0.0.1',args.port),Handler).serve_forever()
